import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { createHash } from "crypto";
import { insertUserSchema, insertGuestimateProblemSchema, insertUserGuesstimateProgressSchema, insertCaseInterviewProblemSchema, insertUserCaseInterviewProgressSchema, insertAptitudeTestSchema, insertAptitudeQuestionSchema, insertUserAptitudeProgressSchema, insertResourceSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { generateCaseInterviewResponse, generateFrameworkSuggestions, analyzeGuestimateSolution } from "./openai";

// Helper functions
const hashPassword = (password: string): string => {
  return createHash("sha256").update(password).digest("hex");
};

export async function registerRoutes(app: Express): Promise<Server> {
  // AUTH ROUTES
  
  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Hash password
      const hashedPassword = hashPassword(userData.password);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      // Get user
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Check password
      const hashedPassword = hashPassword(password);
      if (user.password !== hashedPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(200).json(userWithoutPassword);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get current user
  app.get("/api/auth/user", async (req, res) => {
    try {
      const userId = req.headers["user-id"];
      
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(Number(userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.status(200).json(userWithoutPassword);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // GUESSTIMATE ROUTES
  
  // Get all guesstimate problems
  app.get("/api/guesstimate/problems", async (req, res) => {
    try {
      const problems = await storage.getAllGuesstimateProblems();
      res.status(200).json(problems);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get guesstimate problem by id
  app.get("/api/guesstimate/problems/:id", async (req, res) => {
    try {
      const problemId = Number(req.params.id);
      const problem = await storage.getGuestimateProblem(problemId);
      
      if (!problem) {
        return res.status(404).json({ message: "Problem not found" });
      }
      
      res.status(200).json(problem);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create guesstimate problem
  app.post("/api/guesstimate/problems", async (req, res) => {
    try {
      const problemData = insertGuestimateProblemSchema.parse(req.body);
      const problem = await storage.createGuestimateProblem(problemData);
      res.status(201).json(problem);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Save user guesstimate progress
  app.post("/api/guesstimate/progress", async (req, res) => {
    try {
      const progressData = insertUserGuesstimateProgressSchema.parse(req.body);
      const progress = await storage.saveUserGuesstimateProgress(progressData);
      res.status(201).json(progress);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get user guesstimate progress
  app.get("/api/guesstimate/progress/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const progress = await storage.getUserGuesstimateProgress(userId);
      res.status(200).json(progress);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // CASE INTERVIEW ROUTES
  
  // Get all case interview problems
  app.get("/api/caseinterview/problems", async (req, res) => {
    try {
      const problems = await storage.getAllCaseInterviewProblems();
      res.status(200).json(problems);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get case interview problem by id
  app.get("/api/caseinterview/problems/:id", async (req, res) => {
    try {
      const problemId = Number(req.params.id);
      const problem = await storage.getCaseInterviewProblem(problemId);
      
      if (!problem) {
        return res.status(404).json({ message: "Problem not found" });
      }
      
      res.status(200).json(problem);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create case interview problem
  app.post("/api/caseinterview/problems", async (req, res) => {
    try {
      const problemData = insertCaseInterviewProblemSchema.parse(req.body);
      const problem = await storage.createCaseInterviewProblem(problemData);
      res.status(201).json(problem);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Save user case interview progress
  app.post("/api/caseinterview/progress", async (req, res) => {
    try {
      const progressData = insertUserCaseInterviewProgressSchema.parse(req.body);
      const progress = await storage.saveUserCaseInterviewProgress(progressData);
      res.status(201).json(progress);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get user case interview progress
  app.get("/api/caseinterview/progress/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const progress = await storage.getUserCaseInterviewProgress(userId);
      res.status(200).json(progress);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Chat with AI interviewer
  app.post("/api/caseinterview/chat", async (req, res) => {
    try {
      const { messages, model } = req.body;
      
      if (messages && model) {
        // Handle direct OpenAI chat completion format
        try {
          const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
            },
            body: JSON.stringify({
              model,
              messages
            })
          });
          
          const data = await response.json();
          return res.status(200).json(data);
        } catch (error) {
          console.error("OpenAI API error:", error);
          return res.status(500).json({ message: "Error calling OpenAI API" });
        }
      } else {
        // Handle case interview format
        const { message, conversation, problemId } = req.body;
        
        if (!message || !problemId) {
          return res.status(400).json({ message: "Message and problemId are required" });
        }
        
        // Get the problem to get initial prompt
        const problem = await storage.getCaseInterviewProblem(Number(problemId));
        if (!problem) {
          return res.status(404).json({ message: "Problem not found" });
        }
        
        // Format conversation for OpenAI
        const formattedConversation = conversation ? conversation.map((msg: any) => ({
          role: msg.role,
          content: msg.content
        })) : [];
        
        // Add the latest user message if not already included
        if (!formattedConversation.some((msg: any) => 
            msg.role === "user" && msg.content === message)) {
          formattedConversation.push({
            role: "user",
            content: message
          });
        }
        
        // Generate response using OpenAI
        try {
          const aiResponse = await generateCaseInterviewResponse(
            problem.title,
            problem.description,
            formattedConversation
          );
          
          res.status(200).json({ message: aiResponse });
        } catch (error) {
          console.error("Case interview AI error:", error);
          res.status(500).json({ 
            message: "Sorry, I'm having trouble processing your request. Could you try again?" 
          });
        }
      }
    } catch (err) {
      console.error("Case interview chat error:", err);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // APTITUDE TEST ROUTES
  
  // Get all aptitude tests
  app.get("/api/aptitude/tests", async (req, res) => {
    try {
      const tests = await storage.getAllAptitudeTests();
      res.status(200).json(tests);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get aptitude test by id
  app.get("/api/aptitude/tests/:id", async (req, res) => {
    try {
      const testId = Number(req.params.id);
      const test = await storage.getAptitudeTest(testId);
      
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }
      
      res.status(200).json(test);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create aptitude test
  app.post("/api/aptitude/tests", async (req, res) => {
    try {
      const testData = insertAptitudeTestSchema.parse(req.body);
      const test = await storage.createAptitudeTest(testData);
      res.status(201).json(test);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get questions for aptitude test
  app.get("/api/aptitude/tests/:id/questions", async (req, res) => {
    try {
      const testId = Number(req.params.id);
      const questions = await storage.getAptitudeQuestions(testId);
      res.status(200).json(questions);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create aptitude question
  app.post("/api/aptitude/questions", async (req, res) => {
    try {
      const questionData = insertAptitudeQuestionSchema.parse(req.body);
      const question = await storage.createAptitudeQuestion(questionData);
      res.status(201).json(question);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Save user aptitude progress
  app.post("/api/aptitude/progress", async (req, res) => {
    try {
      const progressData = insertUserAptitudeProgressSchema.parse(req.body);
      const progress = await storage.saveUserAptitudeProgress(progressData);
      res.status(201).json(progress);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get user aptitude progress
  app.get("/api/aptitude/progress/:userId", async (req, res) => {
    try {
      const userId = Number(req.params.userId);
      const progress = await storage.getUserAptitudeProgress(userId);
      res.status(200).json(progress);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // RESOURCE ROUTES
  
  // Get all resources
  app.get("/api/resources", async (req, res) => {
    try {
      const resources = await storage.getAllResources();
      res.status(200).json(resources);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Get resource by id
  app.get("/api/resources/:id", async (req, res) => {
    try {
      const resourceId = Number(req.params.id);
      const resource = await storage.getResource(resourceId);
      
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      res.status(200).json(resource);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create resource
  app.post("/api/resources", async (req, res) => {
    try {
      const resourceData = insertResourceSchema.parse(req.body);
      const resource = await storage.createResource(resourceData);
      res.status(201).json(resource);
    } catch (err) {
      if (err instanceof z.ZodError) {
        const validationError = fromZodError(err);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create the HTTP server
  const httpServer = createServer(app);
  return httpServer;
}