import { 
  users, 
  type User, 
  type InsertUser, 
  guesstimateProblems,
  type GuestimateProblem,
  type InsertGuestimateProblem,
  userGuesstimateProgress,
  type UserGuesstimateProgress,
  type InsertUserGuesstimateProgress,
  caseInterviewProblems,
  type CaseInterviewProblem,
  type InsertCaseInterviewProblem,
  userCaseInterviewProgress,
  type UserCaseInterviewProgress,
  type InsertUserCaseInterviewProgress,
  aptitudeTests,
  type AptitudeTest,
  type InsertAptitudeTest,
  aptitudeQuestions,
  type AptitudeQuestion,
  type InsertAptitudeQuestion,
  userAptitudeProgress,
  type UserAptitudeProgress,
  type InsertUserAptitudeProgress,
  resources,
  type Resource,
  type InsertResource
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User Methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Guesstimate Methods
  getAllGuesstimateProblems(): Promise<GuestimateProblem[]>;
  getGuestimateProblem(id: number): Promise<GuestimateProblem | undefined>;
  createGuestimateProblem(problem: InsertGuestimateProblem): Promise<GuestimateProblem>;
  getUserGuesstimateProgress(userId: number): Promise<UserGuesstimateProgress[]>;
  saveUserGuesstimateProgress(progress: InsertUserGuesstimateProgress): Promise<UserGuesstimateProgress>;
  
  // Case Interview Methods
  getAllCaseInterviewProblems(): Promise<CaseInterviewProblem[]>;
  getCaseInterviewProblem(id: number): Promise<CaseInterviewProblem | undefined>;
  createCaseInterviewProblem(problem: InsertCaseInterviewProblem): Promise<CaseInterviewProblem>;
  getUserCaseInterviewProgress(userId: number): Promise<UserCaseInterviewProgress[]>;
  saveUserCaseInterviewProgress(progress: InsertUserCaseInterviewProgress): Promise<UserCaseInterviewProgress>;
  
  // Aptitude Test Methods
  getAllAptitudeTests(): Promise<AptitudeTest[]>;
  getAptitudeTest(id: number): Promise<AptitudeTest | undefined>;
  createAptitudeTest(test: InsertAptitudeTest): Promise<AptitudeTest>;
  getAptitudeQuestions(testId: number): Promise<AptitudeQuestion[]>;
  createAptitudeQuestion(question: InsertAptitudeQuestion): Promise<AptitudeQuestion>;
  getUserAptitudeProgress(userId: number): Promise<UserAptitudeProgress[]>;
  saveUserAptitudeProgress(progress: InsertUserAptitudeProgress): Promise<UserAptitudeProgress>;
  
  // Resource Methods
  getAllResources(): Promise<Resource[]>;
  getResource(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private guesstimateProblems: Map<number, GuestimateProblem>;
  private userGuesstimateProgress: Map<number, UserGuesstimateProgress>;
  private caseInterviewProblems: Map<number, CaseInterviewProblem>;
  private userCaseInterviewProgress: Map<number, UserCaseInterviewProgress>;
  private aptitudeTests: Map<number, AptitudeTest>;
  private aptitudeQuestions: Map<number, AptitudeQuestion>;
  private userAptitudeProgress: Map<number, UserAptitudeProgress>;
  private resources: Map<number, Resource>;
  
  private currentId: {
    users: number;
    guesstimateProblems: number;
    userGuesstimateProgress: number;
    caseInterviewProblems: number;
    userCaseInterviewProgress: number;
    aptitudeTests: number;
    aptitudeQuestions: number;
    userAptitudeProgress: number;
    resources: number;
  };

  constructor() {
    this.users = new Map();
    this.guesstimateProblems = new Map();
    this.userGuesstimateProgress = new Map();
    this.caseInterviewProblems = new Map();
    this.userCaseInterviewProgress = new Map();
    this.aptitudeTests = new Map();
    this.aptitudeQuestions = new Map();
    this.userAptitudeProgress = new Map();
    this.resources = new Map();
    
    this.currentId = {
      users: 1,
      guesstimateProblems: 1,
      userGuesstimateProgress: 1,
      caseInterviewProblems: 1,
      userCaseInterviewProgress: 1,
      aptitudeTests: 1,
      aptitudeQuestions: 1,
      userAptitudeProgress: 1,
      resources: 1
    };
    
    // Initialize with some sample data
    this.initializeSampleData();
  }

  // User Methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }
  
  // Guesstimate Methods
  async getAllGuesstimateProblems(): Promise<GuestimateProblem[]> {
    return Array.from(this.guesstimateProblems.values());
  }
  
  async getGuestimateProblem(id: number): Promise<GuestimateProblem | undefined> {
    return this.guesstimateProblems.get(id);
  }
  
  async createGuestimateProblem(problem: InsertGuestimateProblem): Promise<GuestimateProblem> {
    const id = this.currentId.guesstimateProblems++;
    const now = new Date();
    const newProblem: GuestimateProblem = {
      ...problem,
      id,
      createdAt: now
    };
    this.guesstimateProblems.set(id, newProblem);
    return newProblem;
  }
  
  async getUserGuesstimateProgress(userId: number): Promise<UserGuesstimateProgress[]> {
    return Array.from(this.userGuesstimateProgress.values()).filter(
      (progress) => progress.userId === userId
    );
  }
  
  async saveUserGuesstimateProgress(progress: InsertUserGuesstimateProgress): Promise<UserGuesstimateProgress> {
    const id = this.currentId.userGuesstimateProgress++;
    const now = new Date();
    const newProgress: UserGuesstimateProgress = {
      ...progress,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.userGuesstimateProgress.set(id, newProgress);
    return newProgress;
  }
  
  // Case Interview Methods
  async getAllCaseInterviewProblems(): Promise<CaseInterviewProblem[]> {
    return Array.from(this.caseInterviewProblems.values());
  }
  
  async getCaseInterviewProblem(id: number): Promise<CaseInterviewProblem | undefined> {
    return this.caseInterviewProblems.get(id);
  }
  
  async createCaseInterviewProblem(problem: InsertCaseInterviewProblem): Promise<CaseInterviewProblem> {
    const id = this.currentId.caseInterviewProblems++;
    const now = new Date();
    const newProblem: CaseInterviewProblem = {
      ...problem,
      id,
      createdAt: now
    };
    this.caseInterviewProblems.set(id, newProblem);
    return newProblem;
  }
  
  async getUserCaseInterviewProgress(userId: number): Promise<UserCaseInterviewProgress[]> {
    return Array.from(this.userCaseInterviewProgress.values()).filter(
      (progress) => progress.userId === userId
    );
  }
  
  async saveUserCaseInterviewProgress(progress: InsertUserCaseInterviewProgress): Promise<UserCaseInterviewProgress> {
    const id = this.currentId.userCaseInterviewProgress++;
    const now = new Date();
    const newProgress: UserCaseInterviewProgress = {
      ...progress,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.userCaseInterviewProgress.set(id, newProgress);
    return newProgress;
  }
  
  // Aptitude Test Methods
  async getAllAptitudeTests(): Promise<AptitudeTest[]> {
    return Array.from(this.aptitudeTests.values());
  }
  
  async getAptitudeTest(id: number): Promise<AptitudeTest | undefined> {
    return this.aptitudeTests.get(id);
  }
  
  async createAptitudeTest(test: InsertAptitudeTest): Promise<AptitudeTest> {
    const id = this.currentId.aptitudeTests++;
    const now = new Date();
    const newTest: AptitudeTest = {
      ...test,
      id,
      createdAt: now
    };
    this.aptitudeTests.set(id, newTest);
    return newTest;
  }
  
  async getAptitudeQuestions(testId: number): Promise<AptitudeQuestion[]> {
    return Array.from(this.aptitudeQuestions.values()).filter(
      (question) => question.testId === testId
    );
  }
  
  async createAptitudeQuestion(question: InsertAptitudeQuestion): Promise<AptitudeQuestion> {
    const id = this.currentId.aptitudeQuestions++;
    const now = new Date();
    const newQuestion: AptitudeQuestion = {
      ...question,
      id,
      createdAt: now
    };
    this.aptitudeQuestions.set(id, newQuestion);
    return newQuestion;
  }
  
  async getUserAptitudeProgress(userId: number): Promise<UserAptitudeProgress[]> {
    return Array.from(this.userAptitudeProgress.values()).filter(
      (progress) => progress.userId === userId
    );
  }
  
  async saveUserAptitudeProgress(progress: InsertUserAptitudeProgress): Promise<UserAptitudeProgress> {
    const id = this.currentId.userAptitudeProgress++;
    const now = new Date();
    const newProgress: UserAptitudeProgress = {
      ...progress,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.userAptitudeProgress.set(id, newProgress);
    return newProgress;
  }
  
  // Resource Methods
  async getAllResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }
  
  async getResource(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }
  
  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.currentId.resources++;
    const now = new Date();
    const newResource: Resource = {
      ...resource,
      id,
      createdAt: now
    };
    this.resources.set(id, newResource);
    return newResource;
  }

  // Initialize some sample data for development
  private initializeSampleData() {
    // Sample Guesstimate Problems
    this.createGuestimateProblem({
      title: "Coffee Shops in Delhi",
      description: "Estimate the number of coffee shops in Delhi, India.",
      difficulty: "intermediate",
      category: "market sizing",
      hints: ["Consider the population of Delhi", "Think about coffee consumption patterns in India", "Consider different types of coffee shops"],
      expertSolution: {
        clarify: "We need to estimate the total number of coffee shops in Delhi, including cafes, stands, and other venues where coffee is the primary product.",
        breakdown: "Total coffee shops = Population × Coffee shops per person",
        estimates: "Delhi population: ~20 million, 1 coffee shop per 10,000 people",
        calculation: "20,000,000 ÷ 10,000 = 2,000 coffee shops",
        sanityCheck: "This seems reasonable for a major city with a growing coffee culture",
        summary: "Based on Delhi's population and estimated coffee consumption, there are approximately 2,000 coffee shops in Delhi."
      }
    });

    this.createGuestimateProblem({
      title: "Tennis Balls in a 747",
      description: "Estimate the number of tennis balls that can fit in a Boeing 747 airplane.",
      difficulty: "intermediate",
      category: "volume estimation",
      hints: ["Consider the volume of a tennis ball", "Consider the usable volume of a Boeing 747", "Don't forget to account for empty space between spheres"],
      expertSolution: {
        clarify: "We need to find how many tennis balls can physically fit inside the entire interior space of a Boeing 747, including cabin, cargo, etc.",
        breakdown: "Total balls = Volume of plane ÷ Effective volume per ball",
        estimates: "747 volume: ~1,000 m³, Tennis ball volume: ~0.000057 m³, Packing efficiency: ~74%",
        calculation: "1,000 ÷ (0.000057 ÷ 0.74) = 13 million tennis balls",
        sanityCheck: "This is a large number but seems reasonable given the size difference",
        summary: "Approximately 13 million tennis balls could fit inside a Boeing 747."
      }
    });

    // Sample Case Interview Problems
    this.createCaseInterviewProblem({
      title: "Coffee Chain Market Entry",
      description: "A major U.S. coffee chain is considering entering the Indian market. Help them evaluate this opportunity.",
      category: "market entry",
      difficulty: "intermediate",
      initialPrompt: "Your client is a large coffee chain based in the United States. They're looking to enter the Indian market for the first time. How would you advise them on this potential market entry?",
      frameworkSuggestions: ["Market Entry Framework", "Porter's Five Forces", "4Ps of Marketing"]
    });

    this.createCaseInterviewProblem({
      title: "Retail Bank Profitability",
      description: "A retail bank is experiencing declining profits. Determine the cause and recommend solutions.",
      category: "profitability",
      difficulty: "advanced",
      initialPrompt: "Your client is a retail bank that has seen declining profits over the past three years. The CEO has asked you to determine the cause and recommend solutions. How would you approach this problem?",
      frameworkSuggestions: ["Profitability Framework", "Revenue Growth Framework", "Cost Reduction Framework"]
    });

    // Sample Aptitude Tests
    this.createAptitudeTest({
      title: "Quantitative Aptitude - Basic",
      description: "Test your basic quantitative and numerical reasoning skills.",
      category: "quantitative",
      difficulty: "beginner",
      timeLimit: 1800 // 30 minutes
    });

    const aptitudeTestId = this.currentId.aptitudeTests - 1;

    // Sample Aptitude Questions
    this.createAptitudeQuestion({
      testId: aptitudeTestId,
      question: "A consulting firm increased its workforce by 30% in 2021. In 2022, they reduced the workforce by 20%. What was the net percentage change in the workforce from the beginning of 2021 to the end of 2022?",
      options: ["4% increase", "4% decrease", "10% increase", "10% decrease"],
      correctOption: 0,
      explanation: "If initial workforce is x, after 30% increase it becomes 1.3x. After 20% reduction, it becomes 1.3x × 0.8 = 1.04x, which is a 4% increase from the original value."
    });

    this.createAptitudeQuestion({
      testId: aptitudeTestId,
      question: "If a project requires 8 consultants working 6 hours per day for 20 days to complete, how many days would it take if 12 consultants work 8 hours per day?",
      options: ["10 days", "12 days", "15 days", "18 days"],
      correctOption: 0,
      explanation: "Using the formula (C₁ × H₁ × D₁) = (C₂ × H₂ × D₂), we get: 8 × 6 × 20 = 12 × 8 × D₂. Solving for D₂ gives us 10 days."
    });

    // Sample Resources
    this.createResource({
      title: "Market Entry Framework",
      description: "A comprehensive framework for analyzing market entry opportunities.",
      category: "frameworks",
      contentType: "text",
      content: "Market Entry Framework: 1. Market attractiveness (size, growth, profitability), 2. Competitive landscape, 3. Company capabilities fit, 4. Entry strategy options, 5. Financial projections, 6. Risk assessment"
    });

    this.createResource({
      title: "Case Interview Preparation Guide",
      description: "A step-by-step guide to preparing for consulting case interviews.",
      category: "guides",
      contentType: "text",
      content: "The ultimate guide to case interview preparation: 1. Understand different case types, 2. Master key frameworks, 3. Practice mental math, 4. Develop structured thinking, 5. Communicate clearly, 6. Practice, practice, practice!"
    });
  }
}

export const storage = new MemStorage();
