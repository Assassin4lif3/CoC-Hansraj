import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

// Initialize OpenAI with the API key
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

/**
 * Get a response from OpenAI's chat completion API
 */
export async function getChatCompletion(messages: ChatMessage[], model = MODEL): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model,
      messages: messages as any,
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw error;
  }
}

/**
 * Generate a case interview response based on a problem description and conversation history
 */
export async function generateCaseInterviewResponse(
  problemTitle: string,
  problemDescription: string,
  conversation: ChatMessage[]
): Promise<string> {
  // Create a system message with instructions tailored to the case interviewer role
  const systemMessage: ChatMessage = {
    role: "system",
    content: `You are an expert case interviewer at a top consulting firm conducting a case interview about "${problemTitle}". 
    
    Your role is to:
    - Ask probing questions to assess the candidate's problem-solving abilities
    - Guide the conversation through a structured case approach
    - Provide realistic case interview feedback and follow-up questions
    - Ask about frameworks the candidate plans to use
    - Push the candidate to make calculations and estimations
    - Challenge assumptions when appropriate
    - Provide small hints when the candidate is stuck, but don't solve the case for them
    
    Case Background: ${problemDescription}
    
    Respond in a professional but conversational tone, as a real case interviewer would.`
  };

  // Combine system message with conversation history
  const messages = [systemMessage, ...conversation];

  // Get response from OpenAI
  return await getChatCompletion(messages);
}

/**
 * Generate framework suggestions for a case
 */
export async function generateFrameworkSuggestions(
  caseCategory: string,
  caseDescription: string
): Promise<string[]> {
  const systemMessage: ChatMessage = {
    role: "system",
    content: `You are an expert consulting coach who recommends frameworks for case interviews.
    Based on the case category and description, suggest the most appropriate frameworks.
    Respond with a JSON array of framework names.`
  };

  const userMessage: ChatMessage = {
    role: "user",
    content: `
    Case Category: ${caseCategory}
    Case Description: ${caseDescription}
    
    Please suggest 3-5 frameworks that would be most appropriate for this case.
    Format your response as a JSON array of strings with just the framework names.
    `
  };

  // Get response from OpenAI
  const response = await getChatCompletion([systemMessage, userMessage]);

  // Parse the response as JSON
  try {
    const parsedResponse = JSON.parse(response);
    return Array.isArray(parsedResponse) ? parsedResponse : [];
  } catch (e) {
    // If parsing fails, try to extract frameworks from text
    const frameworkMatches = response.match(/(['"])(.*?)\1/g);
    return frameworkMatches
      ? frameworkMatches.map(match => match.replace(/['"]/g, ''))
      : ["Profitability Framework", "Market Entry Framework", "Porter's Five Forces"];
  }
}

/**
 * Analyze a guesstimate solution
 */
export async function analyzeGuestimateSolution(
  problemTitle: string,
  problemDescription: string,
  userSolution: string
): Promise<{ feedback: string; score: number }> {
  const systemMessage: ChatMessage = {
    role: "system",
    content: `You are an expert consulting interview coach analyzing a candidate's guesstimate solution.
    Provide constructive feedback on their approach and calculations.
    Grade their solution on a scale of 0-100 based on approach, logical reasoning, and clarity.
    Respond with a JSON object containing "feedback" (string) and "score" (number).`
  };

  const userMessage: ChatMessage = {
    role: "user",
    content: `
    Problem: ${problemTitle}
    Description: ${problemDescription}
    
    User Solution:
    ${userSolution}
    
    Please analyze the solution, provide detailed feedback, and assign a score from 0-100.
    Format your response as a JSON with two fields: "feedback" (string) and "score" (number).
    `
  };

  // Get response from OpenAI
  const response = await getChatCompletion([systemMessage, userMessage]);

  // Parse the response as JSON
  try {
    const parsedResponse = JSON.parse(response);
    return {
      feedback: parsedResponse.feedback || "Analysis completed.",
      score: parsedResponse.score || 0
    };
  } catch (e) {
    // If parsing fails, return the response as is
    return {
      feedback: response,
      score: 70 // Default score if parsing fails
    };
  }
}