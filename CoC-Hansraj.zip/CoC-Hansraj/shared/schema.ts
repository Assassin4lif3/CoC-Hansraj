import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("student"),
  profileImage: text("profile_image"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Guesstimate Problems
export const guesstimateProblems = pgTable("guesstimate_problems", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  difficulty: text("difficulty").notNull(), // beginner, intermediate, advanced
  category: text("category").notNull(),
  hints: jsonb("hints").notNull(), // array of hints
  expertSolution: jsonb("expert_solution").notNull(), // solution for all 6 steps
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertGuestimateProblemSchema = createInsertSchema(guesstimateProblems).omit({
  id: true,
  createdAt: true,
});

// User Guesstimate Progress
export const userGuesstimateProgress = pgTable("user_guesstimate_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  problemId: integer("problem_id").notNull().references(() => guesstimateProblems.id),
  userSolution: jsonb("user_solution"), // user's solution for all 6 steps
  hintsUsed: integer("hints_used").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  score: integer("score"), // Score out of 100
  timeSpent: integer("time_spent"), // Time in seconds
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserGuesstimateProgressSchema = createInsertSchema(userGuesstimateProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Case Interview Problems
export const caseInterviewProblems = pgTable("case_interview_problems", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // market entry, profitability, etc.
  difficulty: text("difficulty").notNull(),
  initialPrompt: text("initial_prompt").notNull(), // Initial AI prompt
  frameworkSuggestions: jsonb("framework_suggestions"), // Suggested frameworks
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCaseInterviewProblemSchema = createInsertSchema(caseInterviewProblems).omit({
  id: true,
  createdAt: true,
});

// User Case Interview Progress
export const userCaseInterviewProgress = pgTable("user_case_interview_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  problemId: integer("problem_id").notNull().references(() => caseInterviewProblems.id),
  conversation: jsonb("conversation"), // Array of messages
  notes: text("notes"),
  completed: boolean("completed").notNull().default(false),
  score: integer("score"), // Score out of 100
  feedback: text("feedback"),
  timeSpent: integer("time_spent"), // Time in seconds
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserCaseInterviewProgressSchema = createInsertSchema(userCaseInterviewProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Aptitude Tests
export const aptitudeTests = pgTable("aptitude_tests", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // logical, quantitative, verbal, data
  difficulty: text("difficulty").notNull(),
  timeLimit: integer("time_limit").notNull(), // Time in seconds
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAptitudeTestSchema = createInsertSchema(aptitudeTests).omit({
  id: true,
  createdAt: true,
});

// Aptitude Questions
export const aptitudeQuestions = pgTable("aptitude_questions", {
  id: serial("id").primaryKey(),
  testId: integer("test_id").notNull().references(() => aptitudeTests.id),
  question: text("question").notNull(),
  options: jsonb("options").notNull(), // Array of options
  correctOption: integer("correct_option").notNull(),
  explanation: text("explanation").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAptitudeQuestionSchema = createInsertSchema(aptitudeQuestions).omit({
  id: true,
  createdAt: true,
});

// User Aptitude Progress
export const userAptitudeProgress = pgTable("user_aptitude_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  testId: integer("test_id").notNull().references(() => aptitudeTests.id),
  answers: jsonb("answers"), // User's answers
  score: integer("score"), // Score out of 100
  completed: boolean("completed").notNull().default(false),
  timeSpent: integer("time_spent"), // Time in seconds
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserAptitudeProgressSchema = createInsertSchema(userAptitudeProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Resources
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // frameworks, guides, videos, etc.
  contentType: text("content_type").notNull(), // pdf, video, text
  content: text("content").notNull(), // URL or content
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type GuestimateProblem = typeof guesstimateProblems.$inferSelect;
export type InsertGuestimateProblem = z.infer<typeof insertGuestimateProblemSchema>;

export type UserGuesstimateProgress = typeof userGuesstimateProgress.$inferSelect;
export type InsertUserGuesstimateProgress = z.infer<typeof insertUserGuesstimateProgressSchema>;

export type CaseInterviewProblem = typeof caseInterviewProblems.$inferSelect;
export type InsertCaseInterviewProblem = z.infer<typeof insertCaseInterviewProblemSchema>;

export type UserCaseInterviewProgress = typeof userCaseInterviewProgress.$inferSelect;
export type InsertUserCaseInterviewProgress = z.infer<typeof insertUserCaseInterviewProgressSchema>;

export type AptitudeTest = typeof aptitudeTests.$inferSelect;
export type InsertAptitudeTest = z.infer<typeof insertAptitudeTestSchema>;

export type AptitudeQuestion = typeof aptitudeQuestions.$inferSelect;
export type InsertAptitudeQuestion = z.infer<typeof insertAptitudeQuestionSchema>;

export type UserAptitudeProgress = typeof userAptitudeProgress.$inferSelect;
export type InsertUserAptitudeProgress = z.infer<typeof insertUserAptitudeProgressSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;
