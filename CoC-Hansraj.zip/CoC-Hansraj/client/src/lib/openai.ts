import { apiRequest } from "./queryClient";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const MODEL = "gpt-4o";

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface ChatCompletionResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

/**
 * Function to interact with the OpenAI chat API through our backend
 */
export async function getChatCompletion(
  messages: ChatMessage[],
  systemMessage?: string
): Promise<string> {
  try {
    // Add system message if provided
    const completeMessages = systemMessage
      ? [{ role: "system", content: systemMessage }, ...messages]
      : messages;

    const response = await apiRequest("POST", "/api/caseinterview/chat", {
      messages: completeMessages,
      model: MODEL
    });

    const data: ChatCompletionResponse = await response.json();

    if (!data.choices || data.choices.length === 0) {
      throw new Error("No response from AI service");
    }

    return data.choices[0].message.content;
  } catch (error) {
    console.error("Error getting chat completion:", error);
    throw error;
  }
}

/**
 * Function to get a case interviewer response
 */
export async function getCaseInterviewResponse(
  userMessage: string,
  conversation: ChatMessage[],
  problemId: number
): Promise<string> {
  try {
    // Add the user's latest message to the conversation
    const updatedConversation = [
      ...conversation,
      { role: "user", content: userMessage }
    ];

    const response = await apiRequest("POST", "/api/caseinterview/chat", {
      message: userMessage,
      conversation: updatedConversation,
      problemId
    });

    const data = await response.json();
    return data.message;
  } catch (error) {
    console.error("Error getting case interview response:", error);
    throw error;
  }
}

/**
 * Function to analyze a guesstimate solution
 */
export async function analyzeGuestimateSolution(
  problemId: number,
  userSolution: any,
  expertSolution: any
): Promise<{ feedback: string; score: number }> {
  try {
    const systemMessage = `
      You are an expert consulting interview coach analyzing a candidate's guesstimate solution.
      Compare their solution to the expert solution and provide constructive feedback.
      Grade their solution on a scale of 0-100 based on accuracy, approach, and logical reasoning.
    `;

    const userMessage = `
      Problem ID: ${problemId}
      
      User Solution:
      ${JSON.stringify(userSolution)}
      
      Expert Solution:
      ${JSON.stringify(expertSolution)}
      
      Please analyze the solution, provide detailed feedback on each step, and assign a score from 0-100.
      Format your response as a JSON with two fields: "feedback" (string) and "score" (number).
    `;

    const response = await getChatCompletion(
      [{ role: "user", content: userMessage }],
      systemMessage
    );

    // Parse the response as JSON
    try {
      const parsedResponse = JSON.parse(response);
      return {
        feedback: parsedResponse.feedback || "Analysis completed.",
        score: parsedResponse.score || 0
      };
    } catch (e) {
      // If parsing fails, return the response as is
      return {
        feedback: response,
        score: 70 // Default score if parsing fails
      };
    }
  } catch (error) {
    console.error("Error analyzing guesstimate solution:", error);
    return {
      feedback: "An error occurred while analyzing your solution. Please try again.",
      score: 0
    };
  }
}

/**
 * Function to get framework suggestions for a case
 */
export async function getFrameworkSuggestions(
  caseCategory: string,
  caseDescription: string
): Promise<string[]> {
  try {
    const systemMessage = `
      You are an expert consulting coach who recommends frameworks for case interviews.
      Based on the case category and description, suggest the most appropriate frameworks.
    `;

    const userMessage = `
      Case Category: ${caseCategory}
      Case Description: ${caseDescription}
      
      Please suggest 3-5 frameworks that would be most appropriate for this case.
      Format your response as a JSON array of strings with just the framework names.
    `;

    const response = await getChatCompletion(
      [{ role: "user", content: userMessage }],
      systemMessage
    );

    // Parse the response as JSON
    try {
      const parsedResponse = JSON.parse(response);
      return Array.isArray(parsedResponse) ? parsedResponse : [];
    } catch (e) {
      // If parsing fails, try to extract frameworks from text
      const frameworkMatches = response.match(/(['"])(.*?)\1/g);
      return frameworkMatches
        ? frameworkMatches.map(match => match.replace(/['"]/g, ''))
        : ["Profitability Framework", "Market Entry Framework", "Porter's Five Forces"];
    }
  } catch (error) {
    console.error("Error getting framework suggestions:", error);
    return ["Profitability Framework", "Market Entry Framework", "Porter's Five Forces"];
  }
}
