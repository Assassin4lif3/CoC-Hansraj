import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardHeader, 
  CardContent, 
} from "@/components/ui/card";
import { 
  Check, 
  ChartLine, 
  Coins, 
  Tag, 
  Handshake, 
  Scissors, 
  Rocket,
  Bot,
  Settings,
  Send,
  User
} from "lucide-react";

const CaseInterviewTrial = () => {
  const [userInput, setUserInput] = useState("");
  const [userNotes, setUserNotes] = useState("");

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-secondary/5 to-secondary/10">
      <div className="max-w-7xl mx-auto">
        <div className="md:flex items-center flex-row-reverse">
          <div className="md:w-1/2 mb-8 md:mb-0 md:pl-12">
            <h2 className="text-3xl font-bold text-dark-gray">AI-Powered Case Interviews</h2>
            <p className="mt-4 text-lg text-gray-600">
              Practice with our intelligent AI interviewer that adapts to your responses and provides real-time feedback.
            </p>

            <div className="mt-8 space-y-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-medium text-dark-gray">Multiple Case Categories</h3>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <div className="flex items-center">
                    <ChartLine className="text-secondary mr-2 h-4 w-4" />
                    <span>Market Entry</span>
                  </div>
                  <div className="flex items-center">
                    <Coins className="text-secondary mr-2 h-4 w-4" />
                    <span>Profitability</span>
                  </div>
                  <div className="flex items-center">
                    <Tag className="text-secondary mr-2 h-4 w-4" />
                    <span>Pricing Strategy</span>
                  </div>
                  <div className="flex items-center">
                    <Handshake className="text-secondary mr-2 h-4 w-4" />
                    <span>M&A</span>
                  </div>
                  <div className="flex items-center">
                    <Scissors className="text-secondary mr-2 h-4 w-4" />
                    <span>Cost Reduction</span>
                  </div>
                  <div className="flex items-center">
                    <Rocket className="text-secondary mr-2 h-4 w-4" />
                    <span>Growth Strategy</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h3 className="font-medium text-dark-gray">Key Features</h3>
                <ul className="mt-3 space-y-2">
                  <li className="flex items-start">
                    <Check className="text-green-500 mt-1 mr-2 h-4 w-4" />
                    <span>Natural conversation flow with context awareness</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-green-500 mt-1 mr-2 h-4 w-4" />
                    <span>Real-time feedback on your responses</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-green-500 mt-1 mr-2 h-4 w-4" />
                    <span>Framework suggestions based on case type</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="text-green-500 mt-1 mr-2 h-4 w-4" />
                    <span>Performance scoring with detailed breakdown</span>
                  </li>
                </ul>
              </div>
            </div>

            <Link href="/caseinterview">
              <Button className="mt-8 bg-secondary hover:bg-secondary/90">
                Try a Case Interview
              </Button>
            </Link>
          </div>
          <div className="md:w-1/2">
            <Card className="shadow-lg overflow-hidden border border-gray-200">
              <CardHeader className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
                <div>
                  <h3 className="font-medium text-lg">Case Interview: Market Entry</h3>
                  <p className="text-gray-500 text-sm">AI Interviewer</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="flex items-center text-green-500">
                    <Bot className="mr-2 h-4 w-4" />
                    <span className="font-medium">Active</span>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Settings className="h-4 w-4 text-gray-500" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="flex h-96">
                  <div className="w-2/3 border-r border-gray-200 flex flex-col">
                    <div className="flex-1 p-4 overflow-y-auto space-y-4">
                      <div className="flex items-start">
                        <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                          <Bot className="text-secondary h-4 w-4" />
                        </div>
                        <div className="bg-gray-100 rounded-lg p-3 max-w-xs sm:max-w-md">
                          <p className="text-gray-700">Your client is a large coffee chain based in the United States. They're looking to enter the Indian market for the first time. How would you advise them on this potential market entry?</p>
                        </div>
                      </div>
                      
                      <div className="flex items-start justify-end">
                        <div className="bg-primary/10 rounded-lg p-3 max-w-xs sm:max-w-md order-1">
                          <p className="text-gray-700">I'll approach this by evaluating the market attractiveness, competitive landscape, and potential entry strategies. First, could you provide any specific objectives the client has for this market entry?</p>
                        </div>
                        <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center ml-2 flex-shrink-0">
                          <User className="text-primary h-4 w-4" />
                        </div>
                      </div>
                      
                      <div className="flex items-start">
                        <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                          <Bot className="text-secondary h-4 w-4" />
                        </div>
                        <div className="bg-gray-100 rounded-lg p-3 max-w-xs sm:max-w-md">
                          <p className="text-gray-700">Good question. The client wants to establish 200 stores across major Indian cities within 5 years. Their primary objectives are to achieve profitability by year 3 and capture at least 10% market share in the premium coffee segment.</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 border-t border-gray-200 flex">
                      <Input 
                        className="flex-1 border border-gray-300 rounded-l-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" 
                        placeholder="Type your response..."
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                      />
                      <Button className="bg-primary text-white px-4 py-2 rounded-r-md hover:bg-primary/90">
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="w-1/3 bg-gray-50 p-4 flex flex-col">
                    <h4 className="font-medium text-sm text-gray-500 uppercase mb-2">Notes</h4>
                    <Textarea 
                      className="flex-1 border border-gray-300 rounded-md p-3 text-sm resize-none" 
                      placeholder="Take notes here..."
                      value={userNotes}
                      onChange={(e) => setUserNotes(e.target.value)}
                    />
                    <div className="mt-4">
                      <h4 className="font-medium text-sm text-gray-500 uppercase mb-2">Suggested Frameworks</h4>
                      <div className="space-y-2">
                        <Button 
                          variant="outline" 
                          className="w-full text-left text-sm justify-start font-normal"
                        >
                          <ChartLine className="text-secondary mr-2 h-4 w-4" />
                          Market Entry Framework
                        </Button>
                        <Button 
                          variant="outline" 
                          className="w-full text-left text-sm justify-start font-normal"
                        >
                          <ChartLine className="text-secondary mr-2 h-4 w-4" />
                          Porter's Five Forces
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CaseInterviewTrial;
