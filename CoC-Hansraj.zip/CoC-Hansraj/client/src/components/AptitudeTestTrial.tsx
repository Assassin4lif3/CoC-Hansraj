import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardHeader, 
  CardContent, 
  CardFooter 
} from "@/components/ui/card";
import { 
  Brain, 
  Calculator, 
  BarChart, 
  MessageSquare,
  Clock,
  Flag,
  ArrowLeft,
  ArrowRight
} from "lucide-react";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface CategoryCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  bgColorClass: string;
}

const CategoryCard = ({ icon, title, description, bgColorClass }: CategoryCardProps) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex">
      <div className={`w-12 h-12 rounded-lg ${bgColorClass} flex items-center justify-center mr-4 text-[#F5F5F5]`}>
        {icon}
      </div>
      <div>
        <h3 className="font-medium text-dark-gray">{title}</h3>
        <p className="text-gray-600 text-sm mt-1">{description}</p>
      </div>
    </div>
  );
};

const AptitudeTestTrial = () => {
  const [selectedOption, setSelectedOption] = useState<string>("");

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="md:flex items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h2 className="text-3xl font-bold text-dark-gray">Comprehensive Aptitude Tests</h2>
            <p className="mt-4 text-lg text-gray-600">
              Sharpen your skills with our extensive question bank covering all aspects of consulting aptitude tests.
            </p>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <CategoryCard 
                icon={<Brain className="h-5 w-5" />}
                title="Logical Reasoning"
                description="Critical thinking and problem-solving scenarios"
                bgColorClass="bg-blue-600"
              />
              <CategoryCard 
                icon={<Calculator className="h-5 w-5" />}
                title="Quantitative Aptitude"
                description="Mathematical and numerical reasoning questions"
                bgColorClass="bg-green-600"
              />
              <CategoryCard 
                icon={<BarChart className="h-5 w-5" />}
                title="Data Interpretation"
                description="Analysis of charts, graphs, and data sets"
                bgColorClass="bg-purple-600"
              />
              <CategoryCard 
                icon={<MessageSquare className="h-5 w-5" />}
                title="Verbal Ability"
                description="Reading comprehension and language skills"
                bgColorClass="bg-amber-500"
              />
            </div>

            <Link href="/aptitudetest">
              <Button className="mt-8 bg-blue-600 hover:bg-blue-700">
                Try an Aptitude Test
              </Button>
            </Link>
          </div>
          <div className="md:w-1/2 md:pl-12">
            <Card className="shadow-lg overflow-hidden border border-gray-200">
              <CardHeader className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
                <div>
                  <h3 className="font-medium text-lg">Quantitative Aptitude</h3>
                  <p className="text-gray-500 text-sm">Question 3 of 20</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="flex items-center text-amber-500">
                    <Clock className="mr-2 h-4 w-4" />
                    <span className="font-medium">17:45</span>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Flag className="h-4 w-4 text-gray-500" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="mb-6">
                  <h4 className="font-medium mb-3">Question:</h4>
                  <p className="text-gray-700">A consulting firm increased its workforce by 30% in 2021. In 2022, they reduced the workforce by 20%. What was the net percentage change in the workforce from the beginning of 2021 to the end of 2022?</p>
                </div>

                <RadioGroup value={selectedOption} onValueChange={setSelectedOption}>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <RadioGroupItem value="A" id="option1" />
                      <Label htmlFor="option1" className="ml-3 text-gray-700">A) 4% increase</Label>
                    </div>
                    <div className="flex items-center">
                      <RadioGroupItem value="B" id="option2" />
                      <Label htmlFor="option2" className="ml-3 text-gray-700">B) 4% decrease</Label>
                    </div>
                    <div className="flex items-center">
                      <RadioGroupItem value="C" id="option3" />
                      <Label htmlFor="option3" className="ml-3 text-gray-700">C) 10% increase</Label>
                    </div>
                    <div className="flex items-center">
                      <RadioGroupItem value="D" id="option4" />
                      <Label htmlFor="option4" className="ml-3 text-gray-700">D) 10% decrease</Label>
                    </div>
                  </div>
                </RadioGroup>

                <div className="flex justify-between mt-8">
                  <Button variant="outline" className="flex items-center gap-1">
                    <ArrowLeft className="h-4 w-4" />
                    Previous
                  </Button>
                  <Button className="bg-blue-600 hover:bg-blue-700 flex items-center gap-1">
                    Next
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AptitudeTestTrial;
