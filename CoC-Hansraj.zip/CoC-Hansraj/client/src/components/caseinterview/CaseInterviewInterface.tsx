import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { CaseInterviewProblem } from "@shared/schema";
import { getCaseInterviewResponse, getFrameworkSuggestions } from "@/lib/openai";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bot,
  User,
  Send,
  Settings,
  Clock,
  ChartLine,
  RefreshCw,
  AlertTriangle,
  Save,
  ThumbsUp,
  ThumbsDown,
  AlertCircle
} from "lucide-react";

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface CaseInterviewInterfaceProps {
  problemId: number;
  userId: number;
}

const CaseInterviewInterface = ({ problemId, userId }: CaseInterviewInterfaceProps) => {
  const { toast } = useToast();
  const [userInput, setUserInput] = useState("");
  const [userNotes, setUserNotes] = useState("");
  const [conversation, setConversation] = useState<ChatMessage[]>([]);
  const [isWaiting, setIsWaiting] = useState(false);
  const [timer, setTimer] = useState(0); // Time in seconds
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [frameworks, setFrameworks] = useState<string[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [score, setScore] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch problem details
  const { data: problem, isLoading } = useQuery({
    queryKey: ["/api/caseinterview/problems", problemId],
    enabled: !!problemId
  });

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversation]);

  // Timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isTimerRunning && !isCompleted) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer + 1);
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [isTimerRunning, isCompleted]);

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Initialize the conversation with the AI interviewer
  useEffect(() => {
    if (problem && conversation.length === 0) {
      // Add the initial prompt from the AI interviewer
      setConversation([
        {
          role: "assistant",
          content: problem.initialPrompt
        }
      ]);

      // Get framework suggestions
      const fetchFrameworks = async () => {
        try {
          const suggestions = await getFrameworkSuggestions(
            problem.category,
            problem.description
          );
          setFrameworks(suggestions);
        } catch (error) {
          console.error("Error fetching framework suggestions:", error);
          // Use fallback frameworks from the problem if available
          if (problem.frameworkSuggestions) {
            setFrameworks(problem.frameworkSuggestions as string[]);
          }
        }
      };

      fetchFrameworks();
    }
  }, [problem, conversation.length]);

  const handleSendMessage = async () => {
    if (!userInput.trim() || !problem) return;
    
    // Add user message to conversation
    const updatedConversation = [
      ...conversation,
      { role: "user", content: userInput }
    ];
    
    setConversation(updatedConversation);
    setUserInput("");
    setIsWaiting(true);
    
    try {
      // Get response from AI interviewer
      const aiResponse = await getCaseInterviewResponse(
        userInput,
        conversation,
        problemId
      );
      
      // Add AI response to conversation
      setConversation([
        ...updatedConversation,
        { role: "assistant", content: aiResponse }
      ]);
    } catch (error) {
      console.error("Error getting AI response:", error);
      toast({
        title: "Error",
        description: "Failed to get a response from the AI interviewer. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsWaiting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const saveNotes = () => {
    toast({
      title: "Notes saved",
      description: "Your notes have been saved successfully.",
    });
  };

  const completeInterview = async () => {
    if (!problem) return;
    
    try {
      // Submit progress to backend
      const response = await fetch("/api/caseinterview/progress", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          userId,
          problemId,
          conversation,
          notes: userNotes,
          completed: true,
          timeSpent: timer,
          score: 0, // Will be updated with AI feedback
          feedback: ""
        })
      });
      
      if (!response.ok) {
        throw new Error("Failed to save progress");
      }
      
      // Get AI feedback on the interview
      // In a real implementation, this would call a backend service to analyze the conversation
      // and provide feedback and scoring
      
      // Simulated feedback for now
      setFeedback(
        "You demonstrated strong structured thinking and asked relevant clarifying questions. " +
        "Your approach to breaking down the market entry strategy was methodical. " +
        "Consider focusing more on quantitative aspects in your analysis and developing stronger " +
        "recommendations with concrete next steps. Overall, you showed good consulting fundamentals."
      );
      setScore(75);
      
      setIsCompleted(true);
      setIsTimerRunning(false);
      
      toast({
        title: "Interview completed",
        description: "Your case interview has been completed successfully.",
      });
    } catch (error) {
      console.error("Error completing interview:", error);
      toast({
        title: "Error",
        description: "Failed to complete the interview. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-secondary" />
      </div>
    );
  }

  if (!problem) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
        <h3 className="text-xl font-semibold mb-2">Problem Not Found</h3>
        <p className="text-gray-600">The requested case interview could not be found.</p>
      </div>
    );
  }

  if (isCompleted) {
    return (
      <Card className="shadow-lg overflow-hidden border border-gray-200">
        <CardHeader className="bg-gray-50 p-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-medium text-lg">{problem.title}</h3>
              <p className="text-gray-500 text-sm">{problem.category} • {problem.difficulty} • Completed</p>
            </div>
            <Badge className="bg-secondary">
              Score: {score}/100
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Tabs defaultValue="feedback">
            <TabsList className="p-4 border-b border-gray-200 w-full">
              <TabsTrigger value="feedback">Feedback</TabsTrigger>
              <TabsTrigger value="conversation">Conversation</TabsTrigger>
              <TabsTrigger value="notes">Your Notes</TabsTrigger>
            </TabsList>
            
            <TabsContent value="feedback" className="p-6">
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6">
                <h4 className="font-medium mb-2">Performance Evaluation</h4>
                <p className="text-gray-700 whitespace-pre-line">{feedback}</p>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Structure & Framework</h4>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm">Rating:</span>
                    <span className="text-sm font-medium">Good</span>
                  </div>
                  <Progress value={80} className="h-2 mb-3" />
                  <p className="text-sm text-gray-600">Your structured approach was effective. Used appropriate frameworks.</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Analysis & Insights</h4>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm">Rating:</span>
                    <span className="text-sm font-medium">Satisfactory</span>
                  </div>
                  <Progress value={65} className="h-2 mb-3" />
                  <p className="text-sm text-gray-600">Good insights but could have gone deeper on market analysis.</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Communication</h4>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm">Rating:</span>
                    <span className="text-sm font-medium">Excellent</span>
                  </div>
                  <Progress value={90} className="h-2 mb-3" />
                  <p className="text-sm text-gray-600">Clear and concise communication throughout the case.</p>
                </div>
              </div>
              
              <div className="mt-8 flex justify-between items-center">
                <div className="flex items-center text-gray-600 text-sm">
                  <Clock className="h-4 w-4 mr-1" />
                  <span>Time: {formatTime(timer)}</span>
                </div>
                <Button 
                  onClick={() => window.location.reload()}
                  className="bg-secondary hover:bg-secondary/90"
                >
                  Try Another Case
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="conversation">
              <div className="p-4 h-[70vh] overflow-y-auto space-y-4">
                {conversation.map((msg, index) => (
                  <div 
                    key={index} 
                    className={`flex items-start ${msg.role === 'user' ? 'justify-end' : ''}`}
                  >
                    {msg.role === 'assistant' && (
                      <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                        <Bot className="text-secondary h-4 w-4" />
                      </div>
                    )}
                    <div 
                      className={`rounded-lg p-3 max-w-xs sm:max-w-md ${
                        msg.role === 'user' 
                          ? 'bg-primary/10 order-1' 
                          : 'bg-gray-100'
                      }`}
                    >
                      <p className="text-gray-700 whitespace-pre-line">{msg.content}</p>
                    </div>
                    {msg.role === 'user' && (
                      <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center ml-2 flex-shrink-0">
                        <User className="text-primary h-4 w-4" />
                      </div>
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </TabsContent>
            
            <TabsContent value="notes" className="p-6">
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 min-h-[400px]">
                <h4 className="font-medium mb-2">Your Case Notes</h4>
                <div className="text-gray-700 whitespace-pre-line">
                  {userNotes || "No notes were taken during this case interview."}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg overflow-hidden border border-gray-200">
      <CardHeader className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="font-medium text-lg">{problem.title}</h3>
          <p className="text-gray-500 text-sm">
            {problem.category} • {problem.difficulty}
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center text-green-500">
            <Bot className="mr-2 h-4 w-4" />
            <span className="font-medium">Active</span>
          </div>
          <div className="flex items-center text-gray-500">
            <Clock className="mr-2 h-4 w-4" />
            <span className="font-medium">{formatTime(timer)}</span>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setIsTimerRunning(!isTimerRunning)}
          >
            <Settings className="h-4 w-4 text-gray-500" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="flex h-[75vh]">
          <div className="w-2/3 border-r border-gray-200 flex flex-col">
            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {conversation.map((msg, index) => (
                <div 
                  key={index} 
                  className={`flex items-start ${msg.role === 'user' ? 'justify-end' : ''}`}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                      <Bot className="text-secondary h-4 w-4" />
                    </div>
                  )}
                  <div 
                    className={`rounded-lg p-3 max-w-xs sm:max-w-md ${
                      msg.role === 'user' 
                        ? 'bg-primary/10 order-1' 
                        : 'bg-gray-100'
                    }`}
                  >
                    <p className="text-gray-700">{msg.content}</p>
                  </div>
                  {msg.role === 'user' && (
                    <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center ml-2 flex-shrink-0">
                      <User className="text-primary h-4 w-4" />
                    </div>
                  )}
                </div>
              ))}
              {isWaiting && (
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                    <Bot className="text-secondary h-4 w-4" />
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3 max-w-xs sm:max-w-md">
                    <div className="flex space-x-2">
                      <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce"></div>
                      <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce delay-75"></div>
                      <div className="h-2 w-2 bg-gray-300 rounded-full animate-bounce delay-150"></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
            <div className="p-4 border-t border-gray-200 flex items-center">
              <Input 
                className="flex-1 border border-gray-300 rounded-l-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50" 
                placeholder="Type your response..."
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isWaiting}
              />
              <Button 
                className="bg-secondary text-white px-4 py-2 rounded-r-md hover:bg-secondary/90"
                onClick={handleSendMessage}
                disabled={isWaiting || !userInput.trim()}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="w-1/3 bg-gray-50 p-4 flex flex-col">
            <h4 className="font-medium text-sm text-gray-500 uppercase mb-2">Notes</h4>
            <Textarea 
              className="flex-1 border border-gray-300 rounded-md p-3 text-sm resize-none mb-4" 
              placeholder="Take notes here..."
              value={userNotes}
              onChange={(e) => setUserNotes(e.target.value)}
            />
            <div className="flex space-x-2 mb-4">
              <Button 
                variant="outline" 
                className="text-gray-600 flex-1 text-sm h-9"
                onClick={saveNotes}
              >
                <Save className="h-4 w-4 mr-2" />
                Save Notes
              </Button>
            </div>
            
            <div>
              <h4 className="font-medium text-sm text-gray-500 uppercase mb-2">Suggested Frameworks</h4>
              <div className="space-y-2 mb-4">
                {frameworks.map((framework, index) => (
                  <Button 
                    key={index}
                    variant="outline" 
                    className="w-full text-left text-sm justify-start font-normal h-auto py-2"
                  >
                    <ChartLine className="text-secondary mr-2 h-4 w-4 flex-shrink-0" />
                    <span>{framework}</span>
                  </Button>
                ))}
              </div>
            </div>
            
            <div className="mt-auto">
              <div className="bg-amber-50 border border-amber-200 rounded-md p-3 mb-4">
                <div className="flex items-start">
                  <AlertCircle className="text-amber-500 h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-sm text-amber-800">Ready to End the Interview?</h4>
                    <p className="text-xs text-amber-700 mt-1">
                      Click the button below when you've completed the case. You'll receive feedback on your performance.
                    </p>
                  </div>
                </div>
              </div>
              
              <Button 
                className="w-full bg-secondary hover:bg-secondary/90"
                onClick={completeInterview}
              >
                Complete Interview
              </Button>
              
              <div className="flex justify-between mt-4">
                <Button variant="ghost" size="sm" className="text-xs text-gray-500">
                  <ThumbsUp className="h-3 w-3 mr-1" />
                  Helpful
                </Button>
                <Button variant="ghost" size="sm" className="text-xs text-gray-500">
                  <ThumbsDown className="h-3 w-3 mr-1" />
                  Not Helpful
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CaseInterviewInterface;
