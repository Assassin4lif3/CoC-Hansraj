import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import logoImage from "../assets/logo.png";

const Navbar = () => {
  const { isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [location] = useLocation();

  const isActive = (path: string) => location === path;

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <img src={logoImage} alt="Cases Over Coffee Logo" className="h-14 w-auto" />
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/">
              <a className={`font-medium ${isActive("/") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                Home
              </a>
            </Link>
            <Link href="/guesstimate">
              <a className={`font-medium ${isActive("/guesstimate") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                Guesstimates
              </a>
            </Link>
            <Link href="/caseinterview">
              <a className={`font-medium ${isActive("/caseinterview") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                Case Interviews
              </a>
            </Link>
            <Link href="/aptitudetest">
              <a className={`font-medium ${isActive("/aptitudetest") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                Aptitude Tests
              </a>
            </Link>
            <Link href="/resources">
              <a className={`font-medium ${isActive("/resources") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                Resources
              </a>
            </Link>
          </nav>
          
          <div className="flex items-center">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <Link href="/dashboard">
                  <Button variant="outline" className="hidden md:flex">
                    Dashboard
                  </Button>
                </Link>
                <Button 
                  onClick={() => {
                    logout();
                    setLocation("/");
                  }}
                >
                  Sign Out
                </Button>
              </div>
            ) : (
              <Link href="/login">
                <Button>Sign In</Button>
              </Link>
            )}
            
            {/* Mobile menu button */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden ml-2">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="flex flex-col gap-4 mt-8">
                  <Link href="/">
                    <a className={`px-3 py-2 rounded-md text-base font-medium ${isActive("/") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                      Home
                    </a>
                  </Link>
                  <Link href="/guesstimate">
                    <a className={`px-3 py-2 rounded-md text-base font-medium ${isActive("/guesstimate") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                      Guesstimates
                    </a>
                  </Link>
                  <Link href="/caseinterview">
                    <a className={`px-3 py-2 rounded-md text-base font-medium ${isActive("/caseinterview") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                      Case Interviews
                    </a>
                  </Link>
                  <Link href="/aptitudetest">
                    <a className={`px-3 py-2 rounded-md text-base font-medium ${isActive("/aptitudetest") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                      Aptitude Tests
                    </a>
                  </Link>
                  <Link href="/resources">
                    <a className={`px-3 py-2 rounded-md text-base font-medium ${isActive("/resources") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                      Resources
                    </a>
                  </Link>
                  
                  {isAuthenticated && (
                    <Link href="/dashboard">
                      <a className={`px-3 py-2 rounded-md text-base font-medium ${isActive("/dashboard") ? "text-primary" : "text-dark-gray hover:text-primary"}`}>
                        Dashboard
                      </a>
                    </Link>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
