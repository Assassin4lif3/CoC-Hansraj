import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const CTASection = () => {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-primary/10">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-3xl font-bold text-dark-gray">Ready to Ace Your Consulting Interviews?</h2>
        <p className="mt-4 text-lg text-gray-600">
          Join hundreds of Hansraj College students who have secured top consulting roles through structured practice.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          <Link href="/register">
            <Button size="lg" className="bg-primary hover:bg-primary/90">
              Sign Up Free
            </Button>
          </Link>
          <Link href="/resources">
            <Button 
              size="lg" 
              variant="outline" 
              className="text-primary border-primary hover:bg-primary/10"
            >
              Learn More
            </Button>
          </Link>
        </div>
        <p className="mt-6 text-gray-500">
          No credit card required. Start practicing today.
        </p>
      </div>
    </section>
  );
};

export default CTASection;
