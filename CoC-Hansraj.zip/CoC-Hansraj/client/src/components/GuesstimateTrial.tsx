import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Card, 
  CardHeader, 
  CardContent, 
  CardFooter 
} from "@/components/ui/card";
import { 
  Clock, 
  HelpCircle, 
  Lightbulb, 
  ArrowRight 
} from "lucide-react";

interface StepItemProps {
  number: number;
  title: string;
  description: string;
}

const StepItem = ({ number, title, description }: StepItemProps) => {
  return (
    <div className="flex items-start">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold mr-4">
        {number}
      </div>
      <div>
        <h3 className="text-lg font-medium text-dark-gray">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
};

const GuesstimateTrial = () => {
  const [step1Value, setStep1Value] = useState("");
  const [step2Value, setStep2Value] = useState("");

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="md:flex items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h2 className="text-3xl font-bold text-dark-gray">Guesstimate Practice Module</h2>
            <p className="mt-4 text-lg text-gray-600">
              Our 6-step framework helps you break down complex estimation problems methodically.
            </p>

            <div className="mt-8 space-y-4">
              <StepItem 
                number={1} 
                title="Clarify Question" 
                description="Define scope and constraints before diving into the problem."
              />
              <StepItem 
                number={2} 
                title="Break Down Problem" 
                description="Split complex problems into manageable components."
              />
              <StepItem 
                number={3} 
                title="Make Estimates" 
                description="Apply reasonable assumptions with logical reasoning."
              />
              <StepItem 
                number={4} 
                title="Calculation" 
                description="Perform structured calculations with our built-in calculator."
              />
              <StepItem 
                number={5} 
                title="Sanity Check" 
                description="Verify if your answer makes logical sense in the real world."
              />
              <StepItem 
                number={6} 
                title="Summarization" 
                description="Present your answer clearly with supporting logic."
              />
            </div>

            <Link href="/guesstimate">
              <Button className="mt-8 bg-primary hover:bg-primary/90">
                Try a Guesstimate Challenge
              </Button>
            </Link>
          </div>
          <div className="md:w-1/2 md:pl-12">
            <Card className="shadow-lg overflow-hidden border border-gray-200">
              <CardHeader className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
                <div>
                  <h3 className="font-medium text-lg">Guesstimate Challenge</h3>
                  <p className="text-gray-500 text-sm">Intermediate Level</p>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="flex items-center text-amber-500">
                    <Clock className="mr-2 h-5 w-5" />
                    <span className="font-medium">12:30</span>
                  </div>
                  <Button variant="ghost" size="icon">
                    <HelpCircle className="h-5 w-5 text-gray-500" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="bg-primary/5 rounded-lg p-4 mb-6">
                  <h4 className="font-medium mb-2">Problem Statement</h4>
                  <p className="text-gray-700">Estimate the number of tennis balls that can fit in a Boeing 747 airplane.</p>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium mb-2 flex items-center">
                      <span className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold mr-2">1</span>
                      Clarify Question
                    </h4>
                    <Textarea 
                      className="w-full border border-gray-300 rounded-md p-3 h-20" 
                      placeholder="Define what we're counting and any constraints..."
                      value={step1Value}
                      onChange={(e) => setStep1Value(e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2 flex items-center">
                      <span className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold mr-2">2</span>
                      Break Down Problem
                    </h4>
                    <Textarea 
                      className="w-full border border-gray-300 rounded-md p-3 h-20" 
                      placeholder="Split the problem into components..."
                      value={step2Value}
                      onChange={(e) => setStep2Value(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <Button variant="outline" className="mr-2 flex items-center gap-1">
                      <Lightbulb className="h-4 w-4" />
                      Hint (3 available)
                    </Button>
                    <Button className="bg-primary hover:bg-primary/90 flex items-center gap-1">
                      Next Step
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GuesstimateTrial;
