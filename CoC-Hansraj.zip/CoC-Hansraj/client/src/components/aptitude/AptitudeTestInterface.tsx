import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { AptitudeTest, AptitudeQuestion } from "@shared/schema";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Clock,
  Flag,
  ArrowLeft,
  ArrowRight,
  Check,
  RefreshCw,
  AlertTriangle,
  BarChart,
  CheckCircle,
  XCircle
} from "lucide-react";

interface AptitudeTestInterfaceProps {
  testId: number;
  userId: number;
}

const AptitudeTestInterface = ({ testId, userId }: AptitudeTestInterfaceProps) => {
  const { toast } = useToast();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>([]);
  const [markedForReview, setMarkedForReview] = useState<boolean[]>([]);
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [isTestCompleted, setIsTestCompleted] = useState(false);
  const [score, setScore] = useState(0);

  // Fetch test details
  const { data: test, isLoading: isLoadingTest } = useQuery({
    queryKey: ["/api/aptitude/tests", testId],
    enabled: !!testId
  });

  // Fetch questions for the test
  const { data: questions, isLoading: isLoadingQuestions } = useQuery({
    queryKey: ["/api/aptitude/tests", testId, "questions"],
    enabled: !!testId
  });

  // Initialize user answers and marked for review arrays
  useEffect(() => {
    if (questions && questions.length > 0) {
      setUserAnswers(new Array(questions.length).fill(null));
      setMarkedForReview(new Array(questions.length).fill(false));
    }
  }, [questions]);

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (test && isTimerRunning && !isTestCompleted) {
      interval = setInterval(() => {
        setTimer(prevTimer => {
          // Check if time limit is reached
          if (test.timeLimit && prevTimer >= test.timeLimit - 1) {
            clearInterval(interval);
            setIsTimerRunning(false);
            toast({
              title: "Time's up!",
              description: "Your time for this test has ended. Submitting your answers...",
              variant: "destructive"
            });
            setTimeout(() => {
              handleSubmitTest();
            }, 2000);
            return test.timeLimit;
          }
          return prevTimer + 1;
        });
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [test, isTimerRunning, isTestCompleted, toast]);

  // Calculate time limit as percentage
  const getTimeProgress = () => {
    if (!test || !test.timeLimit) return 100;
    return Math.min(100, (timer / test.timeLimit) * 100);
  };

  // Get time color based on remaining time
  const getTimeColor = () => {
    if (!test || !test.timeLimit) return "text-gray-500";
    const remainingPercentage = 100 - (timer / test.timeLimit) * 100;
    if (remainingPercentage < 10) return "text-red-500";
    if (remainingPercentage < 25) return "text-amber-500";
    return "text-green-500";
  };

  const handleAnswerChange = (value: string) => {
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestion] = parseInt(value);
    setUserAnswers(newAnswers);
  };

  const handleMarkForReview = () => {
    const newMarked = [...markedForReview];
    newMarked[currentQuestion] = !newMarked[currentQuestion];
    setMarkedForReview(newMarked);
    
    toast({
      title: newMarked[currentQuestion] 
        ? "Marked for review" 
        : "Unmarked from review",
      description: `Question ${currentQuestion + 1} has been ${newMarked[currentQuestion] ? "marked" : "unmarked"}.`,
    });
  };

  const navigateToQuestion = (index: number) => {
    if (index >= 0 && questions && index < questions.length) {
      setCurrentQuestion(index);
    }
  };

  const handleSubmitTest = async () => {
    if (!questions || !test) return;
    
    // Calculate score
    let correctAnswers = 0;
    questions.forEach((question, index) => {
      if (userAnswers[index] === question.correctOption) {
        correctAnswers++;
      }
    });
    
    const calculatedScore = Math.round((correctAnswers / questions.length) * 100);
    setScore(calculatedScore);
    
    try {
      // Submit test results to backend
      const response = await fetch("/api/aptitude/progress", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          userId,
          testId,
          answers: userAnswers,
          score: calculatedScore,
          completed: true,
          timeSpent: timer
        })
      });
      
      if (!response.ok) {
        throw new Error("Failed to submit test results");
      }
      
      setIsTestCompleted(true);
      setIsTimerRunning(false);
      
      toast({
        title: "Test submitted",
        description: "Your answers have been submitted successfully!",
      });
    } catch (error) {
      console.error("Error submitting test:", error);
      toast({
        title: "Submission failed",
        description: "There was an error submitting your test. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (isLoadingTest || isLoadingQuestions) {
    return (
      <div className="flex justify-center items-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!test || !questions || questions.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
        <h3 className="text-xl font-semibold mb-2">Test Not Found</h3>
        <p className="text-gray-600">The requested aptitude test could not be found or has no questions.</p>
      </div>
    );
  }

  if (isTestCompleted) {
    return (
      <Card className="shadow-lg overflow-hidden border border-gray-200">
        <CardHeader className="bg-gray-50 p-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-medium text-lg">{test.title}</h3>
              <p className="text-gray-500 text-sm">{test.category} • {test.difficulty} • Completed</p>
            </div>
            <Badge className="bg-blue-600">
              <BarChart className="mr-1 h-3 w-3" />
              Score: {score}/100
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="p-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-blue-50 mb-4">
                <div className="text-3xl font-bold text-blue-600">{score}%</div>
              </div>
              <h3 className="text-xl font-semibold mb-1">Test Completed!</h3>
              <p className="text-gray-600">
                You answered {userAnswers.filter((answer, index) => answer === questions[index].correctOption).length} out of {questions.length} questions correctly.
              </p>
            </div>
            
            <Tabs defaultValue="results">
              <TabsList className="mb-6 w-full">
                <TabsTrigger value="results">Results</TabsTrigger>
                <TabsTrigger value="review">Review Questions</TabsTrigger>
              </TabsList>
              
              <TabsContent value="results">
                <div className="space-y-6">
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h4 className="font-medium mb-4">Performance Summary</h4>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Accuracy</span>
                          <span className="font-medium">{score}%</span>
                        </div>
                        <Progress value={score} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Time Used</span>
                          <span className="font-medium">{formatTime(timer)} / {formatTime(test.timeLimit)}</span>
                        </div>
                        <Progress value={(timer / test.timeLimit) * 100} className="h-2" />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mt-6">
                        <div className="bg-white p-3 rounded border border-gray-200 text-center">
                          <div className="text-green-600 font-semibold text-xl mb-1">
                            {userAnswers.filter((answer, index) => answer === questions[index].correctOption).length}
                          </div>
                          <div className="text-gray-600 text-sm">Correct</div>
                        </div>
                        <div className="bg-white p-3 rounded border border-gray-200 text-center">
                          <div className="text-red-600 font-semibold text-xl mb-1">
                            {userAnswers.filter((answer, index) => answer !== null && answer !== questions[index].correctOption).length}
                          </div>
                          <div className="text-gray-600 text-sm">Incorrect</div>
                        </div>
                        <div className="bg-white p-3 rounded border border-gray-200 text-center">
                          <div className="text-amber-600 font-semibold text-xl mb-1">
                            {userAnswers.filter(answer => answer === null).length}
                          </div>
                          <div className="text-gray-600 text-sm">Unanswered</div>
                        </div>
                        <div className="bg-white p-3 rounded border border-gray-200 text-center">
                          <div className="text-blue-600 font-semibold text-xl mb-1">
                            {formatTime(Math.floor(timer / questions.length))}
                          </div>
                          <div className="text-gray-600 text-sm">Avg. Time per Question</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="review">
                <div className="space-y-6">
                  {questions.map((question, index) => (
                    <div key={index} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                      <div className="flex justify-between mb-2">
                        <h4 className="font-medium">Question {index + 1}</h4>
                        {userAnswers[index] === question.correctOption ? (
                          <Badge className="bg-green-600">
                            <Check className="h-3 w-3 mr-1" />
                            Correct
                          </Badge>
                        ) : userAnswers[index] === null ? (
                          <Badge className="bg-amber-500">
                            Unanswered
                          </Badge>
                        ) : (
                          <Badge className="bg-red-600">
                            <XCircle className="h-3 w-3 mr-1" />
                            Incorrect
                          </Badge>
                        )}
                      </div>
                      <p className="text-gray-700 mb-4">{question.question}</p>
                      
                      <div className="space-y-2 mb-4">
                        {question.options.map((option, optionIndex) => (
                          <div 
                            key={optionIndex} 
                            className={`flex items-center p-2 rounded ${
                              optionIndex === question.correctOption
                                ? 'bg-green-50 border border-green-200'
                                : userAnswers[index] === optionIndex
                                  ? 'bg-red-50 border border-red-200'
                                  : 'bg-white border border-gray-200'
                            }`}
                          >
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center mr-2 ${
                              optionIndex === question.correctOption
                                ? 'bg-green-100 text-green-600'
                                : userAnswers[index] === optionIndex
                                  ? 'bg-red-100 text-red-600'
                                  : 'bg-gray-100 text-gray-400'
                            }`}>
                              {String.fromCharCode(65 + optionIndex)}
                            </div>
                            <span className="text-gray-700">{option}</span>
                            {optionIndex === question.correctOption && (
                              <CheckCircle className="h-4 w-4 text-green-600 ml-auto" />
                            )}
                          </div>
                        ))}
                      </div>
                      
                      <div className="bg-blue-50 p-3 rounded border border-blue-200">
                        <h5 className="text-sm font-medium text-blue-700 mb-1">Explanation</h5>
                        <p className="text-sm text-blue-800">{question.explanation}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="mt-8 flex justify-center">
              <Button 
                onClick={() => window.location.reload()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Take Another Test
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg overflow-hidden border border-gray-200">
      <CardHeader className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="font-medium text-lg">{test.title}</h3>
          <p className="text-gray-500 text-sm">Question {currentQuestion + 1} of {questions.length}</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className={`flex items-center ${getTimeColor()}`}>
            <Clock className="mr-2 h-5 w-5" />
            <span className="font-medium">{formatTime(test.timeLimit - timer)}</span>
          </div>
          <Button 
            variant="outline"
            size="sm"
            onClick={handleMarkForReview}
            className={markedForReview[currentQuestion] ? "text-amber-600 border-amber-300 bg-amber-50" : ""}
          >
            <Flag className={`h-4 w-4 ${markedForReview[currentQuestion] ? "text-amber-600" : "text-gray-500"}`} />
            <span className="ml-1 text-xs">{markedForReview[currentQuestion] ? "Marked" : "Mark"}</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h4 className="font-medium">Progress</h4>
            <div className="flex items-center">
              <span className="text-xs text-gray-500 mr-2">Time Remaining</span>
              <Progress value={100 - getTimeProgress()} className="h-2 w-32" />
            </div>
          </div>
          <Progress value={(currentQuestion / (questions.length - 1)) * 100} className="h-2" />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Question {currentQuestion + 1}</span>
            <span>Total: {questions.length}</span>
          </div>
        </div>

        <div className="mb-6">
          <h4 className="font-medium mb-4">Question:</h4>
          <p className="text-gray-700">{questions[currentQuestion].question}</p>
        </div>

        <RadioGroup 
          value={userAnswers[currentQuestion]?.toString() || ""} 
          onValueChange={handleAnswerChange}
        >
          <div className="space-y-3">
            {questions[currentQuestion].options.map((option, index) => (
              <div 
                key={index} 
                className="flex items-center p-2 border border-gray-200 rounded hover:bg-gray-50 cursor-pointer"
                onClick={() => handleAnswerChange(index.toString())}
              >
                <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                <Label 
                  htmlFor={`option-${index}`} 
                  className="ml-3 text-gray-700 cursor-pointer flex-1"
                >
                  <div className="flex items-center">
                    <div className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium mr-2">
                      {String.fromCharCode(65 + index)}
                    </div>
                    {option}
                  </div>
                </Label>
              </div>
            ))}
          </div>
        </RadioGroup>
      </CardContent>
      <CardFooter className="bg-gray-50 p-4 border-t border-gray-200 flex flex-col">
        <div className="flex justify-between mb-4">
          <Button 
            variant="outline"
            onClick={() => navigateToQuestion(currentQuestion - 1)}
            disabled={currentQuestion === 0}
            className="flex items-center gap-1"
          >
            <ArrowLeft className="h-4 w-4" />
            Previous
          </Button>
          
          {currentQuestion < questions.length - 1 ? (
            <Button 
              className="bg-blue-600 hover:bg-blue-700 flex items-center gap-1"
              onClick={() => navigateToQuestion(currentQuestion + 1)}
            >
              Next
              <ArrowRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button 
              className="bg-green-600 hover:bg-green-700 flex items-center gap-1"
              onClick={handleSubmitTest}
            >
              Submit Test
            </Button>
          )}
        </div>
        
        <div className="grid grid-cols-8 sm:grid-cols-10 gap-2">
          {questions.map((_, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              className={`h-9 ${
                currentQuestion === index
                  ? 'border-blue-600 bg-blue-50 text-blue-700'
                  : markedForReview[index]
                    ? 'border-amber-300 bg-amber-50 text-amber-700'
                    : userAnswers[index] !== null
                      ? 'border-green-300 bg-green-50 text-green-700'
                      : ''
              }`}
              onClick={() => navigateToQuestion(index)}
            >
              {index + 1}
            </Button>
          ))}
        </div>
        
        <div className="mt-4 flex justify-between">
          <div className="flex items-center space-x-4 text-xs">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-blue-100 border border-blue-600 rounded-sm mr-1"></div>
              <span>Current</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-amber-100 border border-amber-400 rounded-sm mr-1"></div>
              <span>Marked</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-100 border border-green-400 rounded-sm mr-1"></div>
              <span>Answered</span>
            </div>
          </div>
          <div className="text-xs text-gray-500">
            {userAnswers.filter(a => a !== null).length} of {questions.length} answered
          </div>
        </div>
      </CardFooter>
    </Card>
  );
};

export default AptitudeTestInterface;
