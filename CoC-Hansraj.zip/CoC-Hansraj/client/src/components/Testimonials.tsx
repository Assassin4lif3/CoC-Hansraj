import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { Star } from "lucide-react";

interface TestimonialCardProps {
  quote: string;
  name: string;
  position: string;
}

const TestimonialCard = ({ quote, name, position }: TestimonialCardProps) => {
  return (
    <Card className="rounded-xl p-6 shadow-md">
      <div className="flex items-center mb-4">
        <div className="text-primary">
          <Star className="inline-block h-4 w-4 fill-current" />
          <Star className="inline-block h-4 w-4 fill-current" />
          <Star className="inline-block h-4 w-4 fill-current" />
          <Star className="inline-block h-4 w-4 fill-current" />
          <Star className="inline-block h-4 w-4 fill-current" />
        </div>
      </div>
      <CardContent className="p-0">
        <p className="text-gray-700 mb-6">
          {quote}
        </p>
        <div className="flex items-center">
          <div className="w-10 h-10 bg-gray-300 rounded-full mr-3"></div>
          <div>
            <h4 className="font-medium text-dark-gray">{name}</h4>
            <p className="text-gray-500 text-sm">{position}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const Testimonials = () => {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-light-gray">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-dark-gray">Success Stories</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Hear from students who have secured roles at top consulting firms after training with us.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <TestimonialCard 
            quote={"The structured guesstimate framework was a game-changer for me. I went from struggling with estimation problems to solving them confidently. Landed a role at BCG!"}
            name="Priya Sharma"
            position="BCG, Class of 2023"
          />
          <TestimonialCard 
            quote={"The AI case interviews were incredibly realistic. By my actual interview, I had already faced so many scenarios that nothing caught me off guard. Now at Bain & Company!"}
            name="Arjun Patel"
            position="Bain & Company, Class of 2023"
          />
          <TestimonialCard 
            quote={"The aptitude tests helped me identify and improve my weak areas. The personalized analytics were spot on. Successfully placed at McKinsey after 3 months of practice."}
            name="Rohan Mehta"
            position="McKinsey, Class of 2022"
          />
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
