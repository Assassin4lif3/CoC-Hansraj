interface StepProps {
  number: number;
  title: string;
  description: string;
}

const Step = ({ number, title, description }: StepProps) => {
  return (
    <div className="bg-white rounded-xl p-8 shadow-md relative">
      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-bold text-xl mb-6">
        {number}
      </div>
      <h3 className="text-xl font-semibold text-dark-gray mb-4">{title}</h3>
      <p className="text-gray-600">
        {description}
      </p>
      <div className="absolute bottom-0 right-0 h-1 w-1/3 bg-primary rounded-bl-xl"></div>
    </div>
  );
};

const HowItWorks = () => {
  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-light-gray">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-dark-gray">How It Works</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Our structured approach helps you build consulting skills step by step.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Step 
            number={1} 
            title="Practice Systematically" 
            description="Work through our structured modules that build fundamental skills with increasing complexity."
          />
          <Step 
            number={2} 
            title="Get Personalized Feedback" 
            description="Receive detailed analytics on your performance with specific areas for improvement."
          />
          <Step 
            number={3} 
            title="Track Your Progress" 
            description="Monitor your improvement over time and compare with anonymized peer benchmarks."
          />
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
