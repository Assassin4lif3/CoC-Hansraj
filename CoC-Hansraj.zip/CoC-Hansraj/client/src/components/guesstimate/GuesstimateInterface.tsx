import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { GuestimateProblem } from "@shared/schema";
import { analyzeGuestimateSolution } from "@/lib/openai";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { 
  Clock,
  HelpCircle,
  Lightbulb,
  ArrowRight,
  Calculator,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Award
} from "lucide-react";

interface GuesstimateInterfaceProps {
  problemId: number;
  userId: number;
}

// Define a safe problem type that includes default values
interface SafeProblem {
  id: number;
  title: string;
  description: string;
  difficulty: string;
  category: string;
  hints: string[];
  expertSolution: Record<string, string>;
}

const GuesstimateInterface = ({ problemId, userId }: GuesstimateInterfaceProps) => {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(0);
  const [timer, setTimer] = useState(900); // 15 minutes in seconds
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [userSolution, setUserSolution] = useState<Record<string, string>>({
    breakdown: "",
    estimates: "",
    calculation: "",
    sanityCheck: "",
    summary: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [showCalculator, setShowCalculator] = useState(false);
  const [calculatorInput, setCalculatorInput] = useState("");
  const [calculatorHistory, setCalculatorHistory] = useState<string[]>([]);

  // Fetch problem details
  const { data: fetchedProblem, isLoading } = useQuery({
    queryKey: ["/api/guesstimate/problems", problemId],
    enabled: !!problemId
  });
  
  // Create a safe problem object with default values to prevent crashes
  const problem: SafeProblem = {
    id: problemId,
    title: fetchedProblem?.title || "Guesstimate Problem",
    description: fetchedProblem?.description || "Problem description not available.",
    difficulty: fetchedProblem?.difficulty || "Intermediate",
    category: fetchedProblem?.category || "Business",
    hints: Array.isArray(fetchedProblem?.hints) ? fetchedProblem.hints : [],
    expertSolution: fetchedProblem?.expertSolution || {
      breakdown: "Expert solution not available",
      estimates: "Expert solution not available",
      calculation: "Expert solution not available",
      sanityCheck: "Expert solution not available",
      summary: "Expert solution not available"
    }
  };

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  // Timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    } else if (timer === 0) {
      toast({
        title: "Time's up!",
        description: "Your time for this guesstimate has ended.",
        variant: "destructive"
      });
      setIsTimerRunning(false);
    }
    
    return () => clearInterval(interval);
  }, [isTimerRunning, timer, toast]);

  const steps = [
    { name: "Break Down Problem", key: "breakdown" },
    { name: "Make Estimates", key: "estimates" },
    { name: "Calculation", key: "calculation" },
    { name: "Sanity Check", key: "sanityCheck" },
    { name: "Summarization", key: "summary" }
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const useHint = () => {
    if (problem.hints && hintsUsed < problem.hints.length) {
      setHintsUsed(hintsUsed + 1);
      toast({
        title: `Hint ${hintsUsed + 1}`,
        description: problem.hints[hintsUsed] || "No hint available",
      });
    } else {
      toast({
        title: "No more hints",
        description: "You've used all available hints for this problem.",
        variant: "destructive"
      });
    }
  };

  const handleInputChange = (value: string) => {
    setUserSolution({
      ...userSolution,
      [steps[currentStep].key]: value
    });
  };

  const handleSubmit = async () => {
    if (!problem) return;
    
    setIsSubmitting(true);
    
    try {
      // Submit user solution to backend
      const response = await fetch("/api/guesstimate/progress", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          userId,
          problemId,
          userSolution,
          hintsUsed,
          timeSpent: 900 - timer, // Calculate time spent
          completed: true
        })
      });
      
      if (!response.ok) {
        throw new Error("Failed to submit solution");
      }
      
      // Get AI analysis of the solution
      // In a real implementation, this would connect to the OpenAI API
      // For now, use a simulated response
      try {
        const analysis = await analyzeGuestimateSolution(
          problemId,
          userSolution,
          problem.expertSolution
        );
        
        setFeedback(analysis.feedback);
        setScore(analysis.score);
      } catch (error) {
        console.error("Error getting AI analysis:", error);
        // Provide a fallback analysis if the API call fails
        setFeedback("Your solution shows good understanding of the problem. Consider quantifying your assumptions more clearly.");
        setScore(75);
      }
      
      setShowResults(true);
      
      toast({
        title: "Solution submitted",
        description: "Your solution has been submitted successfully!",
      });
    } catch (error) {
      console.error("Error submitting solution:", error);
      toast({
        title: "Submission failed",
        description: "There was an error submitting your solution. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Calculator functions
  const handleCalculatorInput = (value: string) => {
    setCalculatorInput(prev => prev + value);
  };

  const clearCalculator = () => {
    setCalculatorInput("");
  };

  const calculateResult = () => {
    try {
      // eslint-disable-next-line no-eval
      const result = eval(calculatorInput);
      const calculation = `${calculatorInput} = ${result}`;
      setCalculatorHistory([...calculatorHistory, calculation]);
      setCalculatorInput(result.toString());
    } catch (error) {
      setCalculatorInput("Error");
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (showResults) {
    return (
      <Card className="shadow-lg overflow-hidden border border-gray-200">
        <CardHeader className="bg-gray-50 p-4 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-medium text-lg">{problem.title}</h3>
              <p className="text-gray-500 text-sm">{problem.difficulty} Level • Completed</p>
            </div>
            <div>
              <Badge className="bg-primary">
                <Award className="mr-1 h-3 w-3" />
                Score: {score}/100
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <Tabs defaultValue="feedback">
            <TabsList className="mb-6">
              <TabsTrigger value="feedback">Feedback</TabsTrigger>
              <TabsTrigger value="yourSolution">Your Solution</TabsTrigger>
              <TabsTrigger value="expertSolution">Expert Solution</TabsTrigger>
            </TabsList>
            
            <TabsContent value="feedback" className="space-y-4">
              <div className="rounded-lg bg-gray-50 p-6 border border-gray-200">
                <h4 className="font-medium mb-4 text-lg">Analysis & Feedback</h4>
                <div className="whitespace-pre-line text-gray-700">{feedback}</div>
              </div>
              
              <div className="flex justify-between mt-8">
                <div>
                  <h4 className="font-medium mb-2">Performance</h4>
                  <div className="flex gap-4">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-gray-500 mr-1" />
                      <span className="text-sm text-gray-700">Time: {formatTime(900 - timer)}</span>
                    </div>
                    <div className="flex items-center">
                      <Lightbulb className="h-4 w-4 text-gray-500 mr-1" />
                      <span className="text-sm text-gray-700">Hints: {hintsUsed}/{problem.hints.length}</span>
                    </div>
                  </div>
                </div>
                <Button 
                  onClick={() => window.location.reload()}
                  className="bg-primary hover:bg-primary/90"
                >
                  Try Another Problem
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="yourSolution">
              <div className="space-y-6">
                {steps.map((step, index) => (
                  <div key={index} className="rounded-lg bg-gray-50 p-4 border border-gray-200">
                    <h4 className="font-medium mb-2 flex items-center">
                      <span className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold mr-2">
                        {index + 1}
                      </span>
                      {step.name}
                    </h4>
                    <div className="text-gray-700 whitespace-pre-line">
                      {userSolution[step.key] || "No input provided."}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="expertSolution">
              <div className="space-y-6">
                {steps.map((step, index) => (
                  <div key={index} className="rounded-lg bg-gray-50 p-4 border border-gray-200">
                    <h4 className="font-medium mb-2 flex items-center">
                      <span className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold mr-2">
                        {index + 1}
                      </span>
                      {step.name}
                    </h4>
                    <div className="text-gray-700 whitespace-pre-line">
                      {problem.expertSolution[step.key] || "Expert solution not available."}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg overflow-hidden border border-gray-200">
      <CardHeader className="bg-gray-50 p-4 border-b border-gray-200 flex justify-between items-center">
        <div>
          <h3 className="font-medium text-lg">{problem.title}</h3>
          <p className="text-gray-500 text-sm">{problem.difficulty} Level</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className={`flex items-center ${timer < 300 ? 'text-red-500' : 'text-amber-500'}`}>
            <Clock className="mr-2 h-5 w-5" />
            <span className="font-medium">{formatTime(timer)}</span>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsTimerRunning(!isTimerRunning)}
            className="text-gray-500"
          >
            {isTimerRunning ? (
              <span className="text-xs font-medium">PAUSE</span>
            ) : (
              <span className="text-xs font-medium">PLAY</span>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="bg-primary/5 rounded-lg p-4 mb-6">
          <h4 className="font-medium mb-2">Problem Statement</h4>
          <p className="text-gray-700">{problem.description}</p>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-medium">Progress</h4>
            <span className="text-sm text-gray-500">Step {currentStep + 1} of {steps.length}</span>
          </div>
          <Progress value={((currentStep) / (steps.length - 1)) * 100} className="h-2" />
        </div>

        <div className="space-y-6">
          <div>
            <h4 className="font-medium mb-2 flex items-center">
              <span className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold mr-2">
                {currentStep + 1}
              </span>
              {steps[currentStep].name}
            </h4>
            <Textarea 
              className="w-full border border-gray-300 rounded-md p-3 h-36 resize-none" 
              placeholder={`Step ${currentStep + 1}: ${steps[currentStep].name}...`}
              value={userSolution[steps[currentStep].key]}
              onChange={(e) => handleInputChange(e.target.value)}
            />
          </div>
          
          {currentStep === 2 && (
            <div className="flex justify-end">
              <Popover open={showCalculator} onOpenChange={setShowCalculator}>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-1">
                    <Calculator className="h-4 w-4" />
                    Calculator
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="p-1">
                    <div className="bg-gray-100 p-2 rounded mb-2">
                      <div className="text-right text-lg font-medium overflow-x-auto">
                        {calculatorInput || "0"}
                      </div>
                    </div>
                    
                    {calculatorHistory.length > 0 && (
                      <div className="mb-2 max-h-20 overflow-y-auto">
                        {calculatorHistory.map((calc, index) => (
                          <div key={index} className="text-xs text-right text-gray-500 mb-1">
                            {calc}
                          </div>
                        ))}
                      </div>
                    )}
                    
                    <div className="grid grid-cols-4 gap-1">
                      <Button variant="outline" onClick={() => handleCalculatorInput("7")}>7</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("8")}>8</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("9")}>9</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("/")}>/</Button>
                      
                      <Button variant="outline" onClick={() => handleCalculatorInput("4")}>4</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("5")}>5</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("6")}>6</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("*")}>*</Button>
                      
                      <Button variant="outline" onClick={() => handleCalculatorInput("1")}>1</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("2")}>2</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("3")}>3</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("-")}>-</Button>
                      
                      <Button variant="outline" onClick={() => handleCalculatorInput("0")}>0</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput(".")}>.</Button>
                      <Button variant="outline" onClick={clearCalculator}>C</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("+")}>+</Button>
                      
                      <Button variant="outline" className="col-span-2" onClick={() => handleCalculatorInput("()")}>()</Button>
                      <Button variant="outline" onClick={() => handleCalculatorInput("e")}>=</Button>
                      <Button variant="outline" className="bg-primary text-white" onClick={calculateResult}>=</Button>
                    </div>
                    
                    <div className="mt-2 text-xs text-gray-500">
                      Click "=" to calculate.
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          )}
        </div>

        <div className="flex justify-between items-center mt-8">
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={prevStep}
              disabled={currentStep === 0}
              className="flex items-center"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Previous
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={nextStep}
              disabled={currentStep === steps.length - 1}
              className="flex items-center"
            >
              Next
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={useHint}
              disabled={hintsUsed >= problem.hints.length}
              className="flex items-center"
            >
              <Lightbulb className="h-4 w-4 mr-1" />
              Hint ({problem.hints.length - hintsUsed} left)
            </Button>
            <Button 
              size="sm"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="flex items-center"
            >
              {isSubmitting ? (
                <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <CheckCircle className="h-4 w-4 mr-1" />
              )}
              Submit Solution
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default GuesstimateInterface;