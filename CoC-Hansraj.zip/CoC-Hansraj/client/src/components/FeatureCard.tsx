import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader 
} from "@/components/ui/card";
import { ReactNode } from "react";

interface FeatureCardProps {
  title: string;
  description: string;
  imageSrc: string;
  imageSrcAlt: string;
  features: { icon: ReactNode; text: string }[];
  buttonText: string;
  buttonLink: string;
  bgColorClass: string;
  textColorClass: string;
  hoverBgColorClass: string;
}

const FeatureCard = ({
  title,
  description,
  imageSrc,
  imageSrcAlt,
  features,
  buttonText,
  buttonLink,
  bgColorClass,
  textColorClass,
  hoverBgColorClass
}: FeatureCardProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className={`h-48 ${bgColorClass} flex items-center justify-center`}>
        <img 
          src={imageSrc} 
          alt={imageSrcAlt} 
          className="w-full h-full object-cover"
        />
      </div>
      <CardHeader className="p-6">
        <h3 className="text-xl font-semibold text-dark-gray">{title}</h3>
      </CardHeader>
      <CardContent className="p-6 pt-0">
        <p className="text-gray-600">
          {description}
        </p>
        <div className="mt-4 flex items-center text-sm text-gray-500 flex-wrap gap-4">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center">
              <span className="mr-2">{feature.icon}</span>
              <span>{feature.text}</span>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Link href={buttonLink} className="w-full">
          <Button 
            className={`w-full ${bgColorClass} ${textColorClass} hover:${hoverBgColorClass}`}
            variant="ghost"
          >
            {buttonText}
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
};

export default FeatureCard;
