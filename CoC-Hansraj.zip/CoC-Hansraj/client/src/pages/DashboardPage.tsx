import { useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  BookOpen,
  Calculator,
  ChartBar,
  Clock,
  Award,
  CheckSquare
} from "lucide-react";
import { Progress } from "@/components/ui/progress";

const DashboardPage = () => {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  // Fetch user's guesstimate progress
  const { data: guesstimateProgress, isLoading: loadingGuesstimate } = useQuery({
    queryKey: ["/api/guesstimate/progress", user?.id],
    enabled: !!user,
  });

  // Fetch user's case interview progress
  const { data: caseInterviewProgress, isLoading: loadingCaseInterview } = useQuery({
    queryKey: ["/api/caseinterview/progress", user?.id],
    enabled: !!user,
  });

  // Fetch user's aptitude progress
  const { data: aptitudeProgress, isLoading: loadingAptitude } = useQuery({
    queryKey: ["/api/aptitude/progress", user?.id],
    enabled: !!user,
  });

  if (!user) {
    return null; // Will redirect due to useEffect above
  }

  return (
    <>
      <Helmet>
        <title>Dashboard | Cases Over Coffee - Hansraj College</title>
        <meta 
          name="description" 
          content="View your progress and practice history for consulting interviews, guesstimates, and aptitude tests."
        />
      </Helmet>
      
      <div className="py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-dark-gray mb-2">Welcome, {user.fullName}</h1>
          <p className="text-gray-600 mb-8">Track your progress and continue your practice</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <Calculator className="mr-2 h-5 w-5 text-primary" />
                  Guesstimate Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Completed</span>
                    <span className="font-medium">7/20</span>
                  </div>
                  <Progress value={35} className="h-2" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <BookOpen className="mr-2 h-5 w-5 text-secondary" />
                  Case Interview Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Completed</span>
                    <span className="font-medium">5/15</span>
                  </div>
                  <Progress value={33} className="h-2" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <ChartBar className="mr-2 h-5 w-5 text-blue-600" />
                  Aptitude Test Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Completed</span>
                    <span className="font-medium">12/30</span>
                  </div>
                  <Progress value={40} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="overview">
            <TabsList className="mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="guesstimates">Guesstimates</TabsTrigger>
              <TabsTrigger value="caseinterviews">Case Interviews</TabsTrigger>
              <TabsTrigger value="aptitudetests">Aptitude Tests</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl">Recent Activity</CardTitle>
                    <CardDescription>Your latest practice sessions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start gap-4">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <Calculator className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">Market Sizing: Coffee Shops in Delhi</h4>
                              <p className="text-sm text-gray-500">Guesstimate Challenge</p>
                            </div>
                            <span className="text-xs text-gray-500">2 days ago</span>
                          </div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="text-sm text-gray-600">Score: 78/100</span>
                            <span className="text-xs text-gray-500">|</span>
                            <span className="text-sm text-gray-600 flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              15 min
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-4">
                        <div className="bg-secondary/10 p-2 rounded-full">
                          <BookOpen className="h-5 w-5 text-secondary" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">Retail Expansion Strategy</h4>
                              <p className="text-sm text-gray-500">Case Interview</p>
                            </div>
                            <span className="text-xs text-gray-500">5 days ago</span>
                          </div>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="text-sm text-gray-600">Completed</span>
                            <span className="text-xs text-gray-500">|</span>
                            <span className="text-sm text-gray-600 flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              24 min
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl">Your Performance</CardTitle>
                    <CardDescription>How you're doing compared to peers</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Guesstimate Accuracy</span>
                          <span className="font-medium">76%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-primary rounded-full" 
                            style={{ width: '76%' }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">15% above average</div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Case Interview Structure</span>
                          <span className="font-medium">82%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-secondary rounded-full" 
                            style={{ width: '82%' }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">9% above average</div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Quantitative Aptitude</span>
                          <span className="font-medium">64%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-blue-600 rounded-full" 
                            style={{ width: '64%' }}
                          ></div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">5% below average</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl">Your Achievements</CardTitle>
                    <CardDescription>Badges earned through practice</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      <div className="flex flex-col items-center">
                        <div className="bg-primary/10 p-3 rounded-full mb-2">
                          <Award className="h-6 w-6 text-primary" />
                        </div>
                        <span className="text-xs text-center font-medium">Guesstimate Pro</span>
                      </div>
                      
                      <div className="flex flex-col items-center">
                        <div className="bg-secondary/10 p-3 rounded-full mb-2">
                          <CheckSquare className="h-6 w-6 text-secondary" />
                        </div>
                        <span className="text-xs text-center font-medium">Case Master</span>
                      </div>
                      
                      <div className="flex flex-col items-center opacity-40">
                        <div className="bg-blue-600/10 p-3 rounded-full mb-2">
                          <ChartBar className="h-6 w-6 text-blue-600" />
                        </div>
                        <span className="text-xs text-center font-medium">Data Guru</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl">Practice Recommendations</CardTitle>
                    <CardDescription>Based on your performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-blue-600/10 p-2 rounded-full">
                          <Calculator className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">Data Interpretation</h4>
                          <p className="text-sm text-gray-600">
                            Focus on improving your chart reading skills with our data interpretation aptitude tests.
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-start gap-3">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <Clock className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-medium">Calculation Speed</h4>
                          <p className="text-sm text-gray-600">
                            Practice mental math and estimation techniques to improve calculation speed.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="guesstimates">
              <Card>
                <CardHeader>
                  <CardTitle>Guesstimate Practice History</CardTitle>
                  <CardDescription>Your completed and in-progress guesstimate challenges</CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingGuesstimate ? (
                    <p>Loading your guesstimate progress...</p>
                  ) : (
                    <p>Detailed guesstimate practice history will appear here</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="caseinterviews">
              <Card>
                <CardHeader>
                  <CardTitle>Case Interview History</CardTitle>
                  <CardDescription>Your previous case interview practice sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingCaseInterview ? (
                    <p>Loading your case interview progress...</p>
                  ) : (
                    <p>Detailed case interview history will appear here</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="aptitudetests">
              <Card>
                <CardHeader>
                  <CardTitle>Aptitude Test Results</CardTitle>
                  <CardDescription>Your completed aptitude tests and scores</CardDescription>
                </CardHeader>
                <CardContent>
                  {loadingAptitude ? (
                    <p>Loading your aptitude test progress...</p>
                  ) : (
                    <p>Detailed aptitude test results will appear here</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
};

export default DashboardPage;
