import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AptitudeTest } from "@shared/schema";
import AptitudeTestInterface from "@/components/aptitude/AptitudeTestInterface";
import { 
  Brain, 
  Calculator, 
  BarChart, 
  MessageSquare, 
  Clock, 
  ArrowLeftRight,
  ChevronRight,
  CheckCircle,
} from "lucide-react";

const AptitudeTestPage = () => {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedTestId, setSelectedTestId] = useState<number | null>(null);

  // If not logged in, redirect to login page
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Fetch all aptitude tests
  const { data: tests, isLoading } = useQuery({
    queryKey: ["/api/aptitude/tests"],
  });

  // Filter tests based on selected filters
  const filteredTests = tests?.filter((test: AptitudeTest) => {
    if (selectedDifficulty !== "all" && test.difficulty !== selectedDifficulty) {
      return false;
    }
    if (selectedCategory !== "all" && test.category !== selectedCategory) {
      return false;
    }
    return true;
  });

  // Get unique categories and difficulties for filters
  const categories = tests 
    ? Array.from(new Set(tests.map((t: AptitudeTest) => t.category)))
    : [];
  
  const difficulties = tests 
    ? Array.from(new Set(tests.map((t: AptitudeTest) => t.difficulty)))
    : [];

  const handleStartTest = (testId: number) => {
    setSelectedTestId(testId);
    window.scrollTo(0, 0);
  };

  const handleBackToTests = () => {
    setSelectedTestId(null);
  };

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  // Category to icon mapping
  const getCategoryIcon = (category: string) => {
    switch(category) {
      case "logical": return <Brain className="h-12 w-12 text-blue-600" />;
      case "quantitative": return <Calculator className="h-12 w-12 text-green-600" />;
      case "data": return <BarChart className="h-12 w-12 text-purple-600" />;
      case "verbal": return <MessageSquare className="h-12 w-12 text-yellow-600" />;
      default: return <Brain className="h-12 w-12 text-blue-600" />;
    }
  };

  // Category to background color mapping
  const getCategoryBgColor = (category: string) => {
    switch(category) {
      case "logical": return "bg-blue-100";
      case "quantitative": return "bg-green-100";
      case "data": return "bg-purple-100";
      case "verbal": return "bg-yellow-100";
      default: return "bg-blue-100";
    }
  };

  // Category to text color mapping
  const getCategoryTextColor = (category: string) => {
    switch(category) {
      case "logical": return "text-blue-600";
      case "quantitative": return "text-green-600";
      case "data": return "text-purple-600";
      case "verbal": return "text-yellow-600";
      default: return "text-blue-600";
    }
  };

  return (
    <>
      <Helmet>
        <title>Aptitude Tests | Cases Over Coffee - Hansraj College</title>
        <meta 
          name="description" 
          content="Practice with our comprehensive aptitude tests covering logical reasoning, quantitative aptitude, data interpretation, and verbal ability."
        />
      </Helmet>
      
      <div className="py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {selectedTestId ? (
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={handleBackToTests}
                className="mb-4"
              >
                ← Back to Tests
              </Button>
              <AptitudeTestInterface 
                testId={selectedTestId} 
                userId={user?.id || 0} 
              />
            </div>
          ) : (
            <>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-dark-gray">Aptitude Tests</h1>
                  <p className="text-gray-600 mt-2">
                    Sharpen your consulting skills with our comprehensive aptitude test bank
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Select
                    value={selectedDifficulty}
                    onValueChange={setSelectedDifficulty}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Difficulty Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Difficulties</SelectItem>
                      {difficulties.map((difficulty) => (
                        <SelectItem key={difficulty} value={difficulty}>
                          {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                <Card className="bg-blue-50 border-blue-200">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 mb-4">
                        <Brain className="h-8 w-8" />
                      </div>
                      <h3 className="font-medium text-lg mb-2">Logical Reasoning</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Critical thinking and problem-solving scenarios
                      </p>
                      <Button 
                        variant="outline" 
                        className="w-full border-blue-300 text-blue-700 hover:bg-blue-100"
                        onClick={() => setSelectedCategory("logical")}
                      >
                        View Tests
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-green-50 border-green-200">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 rounded-lg bg-green-100 flex items-center justify-center text-green-600 mb-4">
                        <Calculator className="h-8 w-8" />
                      </div>
                      <h3 className="font-medium text-lg mb-2">Quantitative Aptitude</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Mathematical and numerical reasoning questions
                      </p>
                      <Button 
                        variant="outline" 
                        className="w-full border-green-300 text-green-700 hover:bg-green-100"
                        onClick={() => setSelectedCategory("quantitative")}
                      >
                        View Tests
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-purple-50 border-purple-200">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 rounded-lg bg-purple-100 flex items-center justify-center text-purple-600 mb-4">
                        <BarChart className="h-8 w-8" />
                      </div>
                      <h3 className="font-medium text-lg mb-2">Data Interpretation</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Analysis of charts, graphs, and data sets
                      </p>
                      <Button 
                        variant="outline" 
                        className="w-full border-purple-300 text-purple-700 hover:bg-purple-100"
                        onClick={() => setSelectedCategory("data")}
                      >
                        View Tests
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-yellow-50 border-yellow-200">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center">
                      <div className="w-16 h-16 rounded-lg bg-yellow-100 flex items-center justify-center text-yellow-600 mb-4">
                        <MessageSquare className="h-8 w-8" />
                      </div>
                      <h3 className="font-medium text-lg mb-2">Verbal Ability</h3>
                      <p className="text-sm text-gray-600 mb-4">
                        Reading comprehension and language skills
                      </p>
                      <Button 
                        variant="outline" 
                        className="w-full border-yellow-300 text-yellow-700 hover:bg-yellow-100"
                        onClick={() => setSelectedCategory("verbal")}
                      >
                        View Tests
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card className="mb-10">
                <CardHeader>
                  <CardTitle className="text-xl">Your Test Stats</CardTitle>
                  <CardDescription>
                    Track your aptitude test performance and identify areas for improvement
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-center">
                      <h4 className="text-sm text-gray-500 uppercase mb-2">Tests Completed</h4>
                      <div className="text-3xl font-bold">3</div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-center">
                      <h4 className="text-sm text-gray-500 uppercase mb-2">Average Score</h4>
                      <div className="text-3xl font-bold">76%</div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-center">
                      <h4 className="text-sm text-gray-500 uppercase mb-2">Questions Answered</h4>
                      <div className="text-3xl font-bold">48</div>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-center">
                      <h4 className="text-sm text-gray-500 uppercase mb-2">Strongest Category</h4>
                      <div className="text-xl font-medium">Quantitative</div>
                    </div>
                  </div>
                  
                  <div className="flex justify-center mt-6">
                    <Button className="flex items-center gap-1">
                      <ArrowLeftRight className="h-4 w-4" />
                      View Detailed Analytics
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <h2 className="text-xl font-semibold mb-4">Available Aptitude Tests</h2>
              
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-pulse">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
                  ))}
                </div>
              ) : filteredTests && filteredTests.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredTests.map((test: AptitudeTest) => (
                    <Card key={test.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between">
                          <div className="flex items-center">
                            <div className={`w-12 h-12 rounded-lg ${getCategoryBgColor(test.category)} flex items-center justify-center ${getCategoryTextColor(test.category)} mr-4`}>
                              {getCategoryIcon(test.category)}
                            </div>
                            <div>
                              <CardTitle className="text-lg">{test.title}</CardTitle>
                              <CardDescription>
                                {test.category.charAt(0).toUpperCase() + test.category.slice(1)} • {test.difficulty.charAt(0).toUpperCase() + test.difficulty.slice(1)}
                              </CardDescription>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                          {test.description}
                        </p>
                        <div className="flex items-center text-sm text-gray-600 mb-4">
                          <Clock className="h-4 w-4 mr-1 text-gray-400" />
                          <span>{formatTime(test.timeLimit)} time limit</span>
                          <span className="mx-2">•</span>
                          <CheckCircle className="h-4 w-4 mr-1 text-gray-400" />
                          <span>20 questions</span>
                        </div>
                      </CardContent>
                      <CardFooter className="pt-0 flex justify-between items-center">
                        <div className="text-xs text-gray-500 flex items-center">
                          <Brain className="inline h-3 w-3 mr-1" />
                          Test your knowledge
                        </div>
                        <Button 
                          className="bg-blue-600 hover:bg-blue-700" 
                          onClick={() => handleStartTest(test.id)}
                        >
                          Start Test
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <p className="text-gray-600">No aptitude tests found matching your filters.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => {
                      setSelectedDifficulty("all");
                      setSelectedCategory("all");
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              )}
              
              <div className="mt-12 bg-blue-50 rounded-lg p-6 border border-blue-200">
                <h3 className="text-lg font-semibold mb-3 text-blue-800">Tips for Aptitude Test Success</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-1" />
                      <span className="text-sm">Read each question carefully before answering.</span>
                    </p>
                    <p className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-1" />
                      <span className="text-sm">Manage your time wisely - don't spend too long on any one question.</span>
                    </p>
                    <p className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-1" />
                      <span className="text-sm">If unsure, mark the question for review and come back to it later.</span>
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-1" />
                      <span className="text-sm">Eliminate obviously wrong answers to improve your odds.</span>
                    </p>
                    <p className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-1" />
                      <span className="text-sm">Watch out for common data interpretation traps like unit conversions.</span>
                    </p>
                    <p className="flex items-start">
                      <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-1" />
                      <span className="text-sm">Review your performance to identify and focus on weak areas.</span>
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default AptitudeTestPage;
