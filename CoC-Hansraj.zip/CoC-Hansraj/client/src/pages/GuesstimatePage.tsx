import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { GuestimateProblem } from "@shared/schema";
import GuesstimateInterface from "@/components/guesstimate/GuesstimateInterface";
import { Calculator, ChevronRight, BarChart, ArrowLeftRight, Brain } from "lucide-react";

const GuesstimatePage = () => {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedProblemId, setSelectedProblemId] = useState<number | null>(null);

  // If not logged in, redirect to login page
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Fetch all guesstimate problems
  const { data: problems, isLoading } = useQuery({
    queryKey: ["/api/guesstimate/problems"],
  });

  // Filter problems based on selected filters
  const filteredProblems = problems?.filter((problem: GuestimateProblem) => {
    if (selectedDifficulty !== "all" && problem.difficulty !== selectedDifficulty) {
      return false;
    }
    if (selectedCategory !== "all" && problem.category !== selectedCategory) {
      return false;
    }
    return true;
  });

  // Get unique categories and difficulties for filters
  const categories = problems 
    ? Array.from(new Set(problems.map((p: GuestimateProblem) => p.category)))
    : [];
  
  const difficulties = problems 
    ? Array.from(new Set(problems.map((p: GuestimateProblem) => p.difficulty)))
    : [];

  const handleStartProblem = (problemId: number) => {
    setSelectedProblemId(problemId);
    window.scrollTo(0, 0);
  };

  const handleBackToProblems = () => {
    setSelectedProblemId(null);
  };

  return (
    <>
      <Helmet>
        <title>Guesstimate Practice | Cases Over Coffee - Hansraj College</title>
        <meta 
          name="description" 
          content="Practice guesstimate problems with our structured 6-step framework. Improve your estimation skills for consulting interviews."
        />
      </Helmet>
      
      <div className="py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {selectedProblemId ? (
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={handleBackToProblems}
                className="mb-4"
              >
                ← Back to Problems
              </Button>
              <GuesstimateInterface 
                problemId={selectedProblemId} 
                userId={user?.id || 0} 
              />
            </div>
          ) : (
            <>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-dark-gray">Guesstimate Practice</h1>
                  <p className="text-gray-600 mt-2">
                    Master the art of estimation with our structured 6-step framework
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Select
                    value={selectedDifficulty}
                    onValueChange={setSelectedDifficulty}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Difficulty Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Difficulties</SelectItem>
                      {difficulties.map((difficulty) => (
                        <SelectItem key={difficulty} value={difficulty}>
                          {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card className="bg-primary/5 border-primary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center mr-2">
                        <Calculator className="h-4 w-4 text-primary" />
                      </div>
                      The 6-Step Framework
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Our structured approach helps you break down complex estimation problems methodically:
                    </p>
                    <ol className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <span className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold mr-2 flex-shrink-0">1</span>
                        <span>Clarify the question and scope</span>
                      </li>
                      <li className="flex items-start">
                        <span className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold mr-2 flex-shrink-0">2</span>
                        <span>Break down the problem into components</span>
                      </li>
                      <li className="flex items-start">
                        <span className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold mr-2 flex-shrink-0">3</span>
                        <span>Make reasonable estimates</span>
                      </li>
                      <li className="flex items-start">
                        <span className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold mr-2 flex-shrink-0">4</span>
                        <span>Perform calculations</span>
                      </li>
                      <li className="flex items-start">
                        <span className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold mr-2 flex-shrink-0">5</span>
                        <span>Sanity check your answer</span>
                      </li>
                      <li className="flex items-start">
                        <span className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold mr-2 flex-shrink-0">6</span>
                        <span>Summarize your approach and answer</span>
                      </li>
                    </ol>
                  </CardContent>
                </Card>
                
                <Card className="bg-blue-50 border-blue-200">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-2">
                        <Brain className="h-4 w-4 text-blue-600" />
                      </div>
                      Tips for Success
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-0.5" />
                        <span>Use round numbers for easier calculations</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-0.5" />
                        <span>Acknowledge assumptions explicitly</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-0.5" />
                        <span>Think about edge cases and constraints</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-0.5" />
                        <span>Use benchmark figures when possible</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-0.5" />
                        <span>Explain your reasoning clearly</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-blue-600 mr-1 mt-0.5" />
                        <span>Practice mental math regularly</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-green-50 border-green-200">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-2">
                        <BarChart className="h-4 w-4 text-green-600" />
                      </div>
                      Your Progress
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-600 mb-4">
                      Track your improvement over time
                    </CardDescription>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Problems Attempted</span>
                          <span className="font-medium">3/10</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-green-500 rounded-full" 
                            style={{ width: '30%' }}
                          ></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Average Score</span>
                          <span className="font-medium">78/100</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-green-500 rounded-full" 
                            style={{ width: '78%' }}
                          ></div>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        className="w-full mt-2 border-green-300 text-green-700 hover:bg-green-100 flex items-center justify-center gap-1"
                      >
                        <ArrowLeftRight className="h-4 w-4" />
                        View Detailed Analytics
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <h2 className="text-xl font-semibold mb-4">Available Problems</h2>
              
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
                  ))}
                </div>
              ) : filteredProblems && filteredProblems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProblems.map((problem: GuestimateProblem) => (
                    <Card key={problem.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between">
                          <CardTitle className="text-lg">{problem.title}</CardTitle>
                          <div className={`text-xs px-2 py-1 rounded ${
                            problem.difficulty === 'beginner' ? 'bg-green-100 text-green-800' :
                            problem.difficulty === 'intermediate' ? 'bg-amber-100 text-amber-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {problem.difficulty.charAt(0).toUpperCase() + problem.difficulty.slice(1)}
                          </div>
                        </div>
                        <CardDescription>
                          {problem.category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                          {problem.description}
                        </p>
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-500">
                            <Calculator className="inline h-3 w-3 mr-1" />
                            6-step framework
                          </div>
                          <Button 
                            className="bg-primary hover:bg-primary/90" 
                            size="sm"
                            onClick={() => handleStartProblem(problem.id)}
                          >
                            Start
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <p className="text-gray-600">No guesstimate problems found matching your filters.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => {
                      setSelectedDifficulty("all");
                      setSelectedCategory("all");
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default GuesstimatePage;
