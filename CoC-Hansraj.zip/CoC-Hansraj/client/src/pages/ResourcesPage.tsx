import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Input
} from "@/components/ui/input";
import { Resource } from "@shared/schema";
import { 
  Search, 
  FileText, 
  Book, 
  Video, 
  Download, 
  Bookmark, 
  ChevronRight,
  GraduationCap,
  FileSpreadsheet,
  FileCode,
  Briefcase,
  Building,
  ArrowDown,
  Users,
  BarChart4,
  Lightbulb
} from "lucide-react";

const ResourcesPage = () => {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  // Redirect if not authenticated
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Fetch all resources
  const { data: resources, isLoading } = useQuery({
    queryKey: ["/api/resources"],
  });

  // Filter resources based on search term and category
  const filteredResources = resources?.filter((resource: Resource) => {
    const matchesSearch = 
      searchTerm === "" || 
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = 
      selectedCategory === "all" || 
      resource.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  // Get content type icon
  const getContentTypeIcon = (contentType: string) => {
    switch(contentType) {
      case "pdf": return <FileText className="h-5 w-5 text-red-500" />;
      case "video": return <Video className="h-5 w-5 text-blue-500" />;
      case "text": return <Book className="h-5 w-5 text-green-500" />;
      default: return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  // Get category icon
  const getCategoryIcon = (category: string) => {
    switch(category) {
      case "frameworks": return <FileSpreadsheet className="h-5 w-5 text-purple-500" />;
      case "guides": return <Book className="h-5 w-5 text-blue-500" />;
      case "videos": return <Video className="h-5 w-5 text-red-500" />;
      case "templates": return <FileCode className="h-5 w-5 text-green-500" />;
      default: return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  // Popular consulting frameworks
  const frameworks = [
    { name: "Profitability Framework", icon: <BarChart4 className="h-5 w-5" /> },
    { name: "Porter's Five Forces", icon: <Users className="h-5 w-5" /> },
    { name: "4Ps of Marketing", icon: <Briefcase className="h-5 w-5" /> },
    { name: "BCG Matrix", icon: <FileSpreadsheet className="h-5 w-5" /> },
    { name: "SWOT Analysis", icon: <ArrowDown className="h-5 w-5" /> },
    { name: "7S Framework", icon: <Building className="h-5 w-5" /> },
  ];

  // Top consulting firms
  const topFirms = [
    "McKinsey & Company",
    "Boston Consulting Group (BCG)",
    "Bain & Company",
    "Deloitte Consulting",
    "Accenture",
    "KPMG",
    "PwC",
    "EY"
  ];

  return (
    <>
      <Helmet>
        <title>Resources | Cases Over Coffee - Hansraj College</title>
        <meta 
          name="description" 
          content="Access a comprehensive library of consulting resources, frameworks, guides, and practice materials to help you excel in case interviews."
        />
      </Helmet>
      
      <div className="py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold text-dark-gray">Resource Library</h1>
              <p className="text-gray-600 mt-2">
                Access a comprehensive library of consulting resources and reference materials
              </p>
            </div>
            <div className="relative w-full md:w-auto">
              <Input
                placeholder="Search resources..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full md:w-80"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>
          </div>
          
          <Tabs defaultValue="all" onValueChange={setSelectedCategory}>
            <div className="bg-gray-50 p-4 rounded-lg mb-8">
              <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
                <TabsTrigger value="all">All Resources</TabsTrigger>
                <TabsTrigger value="frameworks">Frameworks</TabsTrigger>
                <TabsTrigger value="guides">Guides</TabsTrigger>
                <TabsTrigger value="videos">Videos</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
              </TabsList>
            </div>
            
            <div className="mb-8">
              <Card className="bg-gradient-to-r from-orange-50 to-amber-50 border-none">
                <CardContent className="p-8">
                  <div className="flex flex-col md:flex-row justify-between items-center gap-6">
                    <div>
                      <h2 className="text-2xl font-bold text-dark-gray mb-3">New to Case Interviews?</h2>
                      <p className="text-gray-700 mb-6 max-w-xl">
                        Start with our comprehensive guide covering all aspects of consulting case interviews, from understanding case types to mastering frameworks.
                      </p>
                      <Button className="bg-primary hover:bg-primary/90">
                        <GraduationCap className="mr-2 h-5 w-5" />
                        Access the Beginner's Guide
                      </Button>
                    </div>
                    <div className="h-40 w-40 flex-shrink-0 bg-orange-100 rounded-full flex items-center justify-center">
                      <Lightbulb className="h-20 w-20 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-pulse">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="h-40 bg-gray-200 rounded-lg"></div>
                ))}
              </div>
            ) : filteredResources && filteredResources.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredResources.map((resource: Resource) => (
                  <Card key={resource.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between">
                        <div className="flex items-center">
                          {getCategoryIcon(resource.category)}
                          <CardTitle className="text-lg ml-2">{resource.title}</CardTitle>
                        </div>
                        <Button variant="ghost" size="icon">
                          <Bookmark className="h-5 w-5 text-gray-400" />
                        </Button>
                      </div>
                      <CardDescription className="flex items-center mt-1">
                        {getContentTypeIcon(resource.contentType)}
                        <span className="ml-1 capitalize">{resource.contentType}</span>
                        <span className="mx-2">•</span>
                        <span className="capitalize">{resource.category}</span>
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 text-sm mb-4">
                        {resource.description}
                      </p>
                    </CardContent>
                    <CardFooter className="pt-0">
                      <Button 
                        className="w-full flex items-center justify-center gap-2"
                        variant="outline"
                      >
                        <Download className="h-4 w-4" />
                        Access Resource
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <p className="text-gray-600">No resources found matching your search criteria.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => {
                    setSearchTerm("");
                    setSelectedCategory("all");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </Tabs>
          
          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Popular Consulting Frameworks</CardTitle>
                <CardDescription>
                  Master these essential frameworks for case interviews
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {frameworks.map((framework, index) => (
                    <div key={index} className="flex items-start p-3 bg-gray-50 rounded-md hover:bg-gray-100 transition-colors">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3 flex-shrink-0">
                        {framework.icon}
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{framework.name}</h4>
                        <Button 
                          variant="ghost" 
                          className="px-0 py-1 h-auto text-primary text-sm hover:bg-transparent hover:text-primary/80"
                        >
                          View Framework
                          <ChevronRight className="ml-1 h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Top Consulting Firms</CardTitle>
                <CardDescription>
                  Learn about the leading consulting companies
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {topFirms.map((firm, index) => (
                    <div key={index} className="flex items-center p-3 bg-gray-50 rounded-md hover:bg-gray-100 transition-colors">
                      <Building className="h-5 w-5 text-gray-500 mr-2" />
                      <span className="font-medium text-gray-800">{firm}</span>
                    </div>
                  ))}
                </div>
                <Button 
                  variant="outline" 
                  className="w-full mt-4"
                >
                  View All Firms
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-12 bg-blue-50 rounded-lg p-6 border border-blue-200">
            <h3 className="text-xl font-semibold mb-4 text-blue-800">Interview Preparation Timeline</h3>
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold text-lg mr-4 flex-shrink-0">
                  1
                </div>
                <div>
                  <h4 className="font-medium text-blue-900 text-lg mb-1">2-3 Months Before</h4>
                  <p className="text-blue-800">
                    Start with core frameworks and practice guesstimates daily. Read case interview books and build your mental math skills.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold text-lg mr-4 flex-shrink-0">
                  2
                </div>
                <div>
                  <h4 className="font-medium text-blue-900 text-lg mb-1">1-2 Months Before</h4>
                  <p className="text-blue-800">
                    Practice full-length cases with our AI interviewer. Focus on specific industries and case types. Join peer practice groups.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold text-lg mr-4 flex-shrink-0">
                  3
                </div>
                <div>
                  <h4 className="font-medium text-blue-900 text-lg mb-1">2-3 Weeks Before</h4>
                  <p className="text-blue-800">
                    Take timed aptitude tests and review your performance analytics. Focus on strengthening your weak areas.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold text-lg mr-4 flex-shrink-0">
                  4
                </div>
                <div>
                  <h4 className="font-medium text-blue-900 text-lg mb-1">Final Week</h4>
                  <p className="text-blue-800">
                    Review all frameworks, do light practice, and focus on mental preparation. Get good rest before interview day.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ResourcesPage;
