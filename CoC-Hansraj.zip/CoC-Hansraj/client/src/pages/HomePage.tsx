import { Helmet } from "react-helmet";
import Hero from "@/components/Hero";
import FeatureCard from "@/components/FeatureCard";
import HowItWorks from "@/components/HowItWorks";
import GuesstimateTrial from "@/components/GuesstimateTrial";
import CaseInterviewTrial from "@/components/CaseInterviewTrial";
import AptitudeTestTrial from "@/components/AptitudeTestTrial";
import Testimonials from "@/components/Testimonials";
import CTASection from "@/components/CTASection";
import {
  Clock,
  Lightbulb,
  Bot,
  MessageSquare,
  Brain,
  BarChart
} from "lucide-react";

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>Cases Over Coffee - Practice Consulting Case Interviews | Hansraj College</title>
        <meta 
          name="description" 
          content="Prepare for consulting interviews with Cases Over Coffee at Hansraj College. Practice guesstimates, case interviews, and aptitude tests to land your dream consulting role."
        />
        <meta property="og:title" content="Cases Over Coffee - Hansraj College" />
        <meta property="og:description" content="Practice platform for consulting case interviews, guesstimates, and aptitude tests." />
        <meta property="og:type" content="website" />
      </Helmet>
      
      <Hero />
      
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-dark-gray">Practice Makes Perfect</h2>
            <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
              Our comprehensive platform offers three specialized modules to help you excel in every aspect of consulting interviews.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              title="Guesstimate Practice"
              description="Master the art of estimation with our structured 6-step framework, timed challenges, and expert solutions."
              imageSrc="https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              imageSrcAlt="Guesstimate practice session"
              features={[
                { icon: <Clock className="h-4 w-4" />, text: "Timed practice" },
                { icon: <Lightbulb className="h-4 w-4" />, text: "Hint system" }
              ]}
              buttonText="Try Guesstimates"
              buttonLink="/guesstimate"
              bgColorClass="bg-primary/10"
              textColorClass="text-primary"
              hoverBgColorClass="bg-primary/20"
            />
            
            <FeatureCard 
              title="AI Case Interviews"
              description="Practice with our AI interviewer that simulates real consulting interviews across multiple case categories."
              imageSrc="https://images.unsplash.com/photo-1560439514-4e9645039924?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              imageSrcAlt="Case interview with AI"
              features={[
                { icon: <Bot className="h-4 w-4" />, text: "AI simulation" },
                { icon: <MessageSquare className="h-4 w-4" />, text: "Real-time feedback" }
              ]}
              buttonText="Try Case Interviews"
              buttonLink="/caseinterview"
              bgColorClass="bg-secondary/10"
              textColorClass="text-secondary"
              hoverBgColorClass="bg-secondary/20"
            />
            
            <FeatureCard 
              title="Aptitude Tests"
              description="Sharpen your logical reasoning, quantitative, and verbal skills with our extensive question bank."
              imageSrc="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              imageSrcAlt="Aptitude test analytics"
              features={[
                { icon: <Brain className="h-4 w-4" />, text: "Comprehensive tests" },
                { icon: <BarChart className="h-4 w-4" />, text: "Performance analytics" }
              ]}
              buttonText="Try Aptitude Tests"
              buttonLink="/aptitudetest"
              bgColorClass="bg-dark-gray/10"
              textColorClass="text-dark-gray"
              hoverBgColorClass="bg-dark-gray/20"
            />
          </div>
        </div>
      </section>
      
      <HowItWorks />
      <GuesstimateTrial />
      <CaseInterviewTrial />
      <AptitudeTestTrial />
      <Testimonials />
      <CTASection />
    </>
  );
};

export default HomePage;
