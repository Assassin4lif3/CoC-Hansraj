import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CaseInterviewProblem } from "@shared/schema";
import CaseInterviewInterface from "@/components/caseinterview/CaseInterviewInterface";
import { 
  ChevronRight, 
  Bot, 
  MessageSquare, 
  BookOpen, 
  ChartLine, 
  Coins, 
  Tag, 
  Handshake, 
  Scissors, 
  Rocket,
  ArrowLeftRight
} from "lucide-react";

const CaseInterviewPage = () => {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedProblemId, setSelectedProblemId] = useState<number | null>(null);

  // If not logged in, redirect to login page
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Fetch all case interview problems
  const { data: problems, isLoading } = useQuery({
    queryKey: ["/api/caseinterview/problems"],
  });

  // Filter problems based on selected filters
  const filteredProblems = problems?.filter((problem: CaseInterviewProblem) => {
    if (selectedDifficulty !== "all" && problem.difficulty !== selectedDifficulty) {
      return false;
    }
    if (selectedCategory !== "all" && problem.category !== selectedCategory) {
      return false;
    }
    return true;
  });

  // Get unique categories and difficulties for filters
  const categories = problems 
    ? Array.from(new Set(problems.map((p: CaseInterviewProblem) => p.category)))
    : [];
  
  const difficulties = problems 
    ? Array.from(new Set(problems.map((p: CaseInterviewProblem) => p.difficulty)))
    : [];

  const handleStartInterview = (problemId: number) => {
    setSelectedProblemId(problemId);
    window.scrollTo(0, 0);
  };

  const handleBackToProblems = () => {
    setSelectedProblemId(null);
  };

  // Category to icon mapping
  const getCategoryIcon = (category: string) => {
    switch(category) {
      case "market entry": return <ChartLine className="h-4 w-4 text-secondary" />;
      case "profitability": return <Coins className="h-4 w-4 text-secondary" />;
      case "pricing strategy": return <Tag className="h-4 w-4 text-secondary" />;
      case "merger & acquisition": return <Handshake className="h-4 w-4 text-secondary" />;
      case "cost reduction": return <Scissors className="h-4 w-4 text-secondary" />;
      case "growth strategy": return <Rocket className="h-4 w-4 text-secondary" />;
      default: return <BookOpen className="h-4 w-4 text-secondary" />;
    }
  };

  return (
    <>
      <Helmet>
        <title>Case Interviews | Cases Over Coffee - Hansraj College</title>
        <meta 
          name="description" 
          content="Practice case interviews with our AI-powered interviewer. Get real-time feedback and improve your consulting interview skills."
        />
      </Helmet>
      
      <div className="py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {selectedProblemId ? (
            <div className="mb-6">
              <Button 
                variant="outline" 
                onClick={handleBackToProblems}
                className="mb-4"
              >
                ← Back to Cases
              </Button>
              <CaseInterviewInterface 
                problemId={selectedProblemId} 
                userId={user?.id || 0} 
              />
            </div>
          ) : (
            <>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-dark-gray">AI Case Interviews</h1>
                  <p className="text-gray-600 mt-2">
                    Practice with our AI interviewer that simulates real consulting interviews
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Select
                    value={selectedDifficulty}
                    onValueChange={setSelectedDifficulty}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Difficulty Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Difficulties</SelectItem>
                      {difficulties.map((difficulty) => (
                        <SelectItem key={difficulty} value={difficulty}>
                          {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card className="bg-secondary/5 border-secondary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center mr-2">
                        <Bot className="h-4 w-4 text-secondary" />
                      </div>
                      AI-Powered Interviews
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Our AI interviewer adapts to your responses, providing a realistic case interview experience:
                    </p>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-secondary mr-1 mt-0.5" />
                        <span>Natural conversation flow with context awareness</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-secondary mr-1 mt-0.5" />
                        <span>Real-time feedback on your responses</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-secondary mr-1 mt-0.5" />
                        <span>Framework suggestions based on case type</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-secondary mr-1 mt-0.5" />
                        <span>Performance scoring with detailed breakdown</span>
                      </li>
                      <li className="flex items-start">
                        <ChevronRight className="h-4 w-4 text-secondary mr-1 mt-0.5" />
                        <span>Note-taking area to organize your thoughts</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card className="bg-blue-50 border-blue-200">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-2">
                        <MessageSquare className="h-4 w-4 text-blue-600" />
                      </div>
                      Case Categories
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-600 mb-4">
                      Practice a wide range of case types:
                    </CardDescription>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center">
                        <ChartLine className="text-secondary mr-2 h-4 w-4" />
                        <span className="text-sm">Market Entry</span>
                      </div>
                      <div className="flex items-center">
                        <Coins className="text-secondary mr-2 h-4 w-4" />
                        <span className="text-sm">Profitability</span>
                      </div>
                      <div className="flex items-center">
                        <Tag className="text-secondary mr-2 h-4 w-4" />
                        <span className="text-sm">Pricing Strategy</span>
                      </div>
                      <div className="flex items-center">
                        <Handshake className="text-secondary mr-2 h-4 w-4" />
                        <span className="text-sm">M&A</span>
                      </div>
                      <div className="flex items-center">
                        <Scissors className="text-secondary mr-2 h-4 w-4" />
                        <span className="text-sm">Cost Reduction</span>
                      </div>
                      <div className="flex items-center">
                        <Rocket className="text-secondary mr-2 h-4 w-4" />
                        <span className="text-sm">Growth Strategy</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-green-50 border-green-200">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-2">
                        <ChartLine className="h-4 w-4 text-green-600" />
                      </div>
                      Your Progress
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-600 mb-4">
                      Track your case interview performance
                    </CardDescription>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Cases Completed</span>
                          <span className="font-medium">2/12</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-green-500 rounded-full" 
                            style={{ width: '16.67%' }}
                          ></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Average Performance</span>
                          <span className="font-medium">73/100</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full">
                          <div 
                            className="h-full bg-green-500 rounded-full" 
                            style={{ width: '73%' }}
                          ></div>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        className="w-full mt-2 border-green-300 text-green-700 hover:bg-green-100 flex items-center justify-center gap-1"
                      >
                        <ArrowLeftRight className="h-4 w-4" />
                        View Detailed Analytics
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <h2 className="text-xl font-semibold mb-4">Available Case Interviews</h2>
              
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div key={i} className="h-48 bg-gray-200 rounded-lg"></div>
                  ))}
                </div>
              ) : filteredProblems && filteredProblems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProblems.map((problem: CaseInterviewProblem) => (
                    <Card key={problem.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between">
                          <CardTitle className="text-lg">{problem.title}</CardTitle>
                          <div className={`text-xs px-2 py-1 rounded ${
                            problem.difficulty === 'beginner' ? 'bg-green-100 text-green-800' :
                            problem.difficulty === 'intermediate' ? 'bg-amber-100 text-amber-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {problem.difficulty.charAt(0).toUpperCase() + problem.difficulty.slice(1)}
                          </div>
                        </div>
                        <CardDescription className="flex items-center">
                          {getCategoryIcon(problem.category)}
                          <span className="ml-1">
                            {problem.category.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          </span>
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                          {problem.description}
                        </p>
                        <div className="flex justify-between items-center">
                          <div className="text-xs text-gray-500">
                            <Bot className="inline h-3 w-3 mr-1" />
                            AI interviewer
                          </div>
                          <Button 
                            className="bg-secondary hover:bg-secondary/90" 
                            size="sm"
                            onClick={() => handleStartInterview(problem.id)}
                          >
                            Start
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <p className="text-gray-600">No case interviews found matching your filters.</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => {
                      setSelectedDifficulty("all");
                      setSelectedCategory("all");
                    }}
                  >
                    Clear Filters
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default CaseInterviewPage;
